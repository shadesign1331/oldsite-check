import type { Product } from "./catalog";
import { calcPrice, selectionLabel, type Selection } from "./pricing";
import type { CartItem } from "@/components/StoreProvider";

export function defaultSelection(p: Product): Selection {
  if (p.kind === "roses") return { color: "mix-bright", height: 35, count: p.roseCount, packaging: "ribbon" };
  if (p.kind === "gift") return {};
  return { size: "s", packaging: "ribbon" };
}

export function buildCartItem(p: Product, sel: Selection): Omit<CartItem, "qty"> {
  return {
    key: p.slug + ":" + JSON.stringify(sel),
    slug: p.slug,
    name: p.name,
    image: p.images[0] ?? null,
    emoji: p.emoji,
    price: calcPrice(p, sel),
    options: sel,
    optionsLabel: selectionLabel(p, sel),
  };
}
