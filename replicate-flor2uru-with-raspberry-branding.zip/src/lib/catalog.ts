import { menuTitleMap } from "./menu";
import type { Kind } from "./pricing";

export type Product = {
  slug: string;
  name: string;
  price: number;
  oldPrice?: number;
  kind: Kind;
  roseCount?: number;
  images: string[];
  emoji?: string;
  flowers: string[];
  tags: string[];
  popularity: number;
  isNew?: boolean;
  description: string;
};

const FL: Record<string, [string, string]> = {
  roz: ["bukety-roz", "розы"],
  rom: ["romashki", "ромашки"],
  ger: ["bukety-gerberov", "герберы"],
  khr: ["bukety-khrizantem", "хризантемы"],
  pod: ["podsolnuhi", "подсолнухи"],
  alt: ["bukety-alstromeriy", "альстромерии"],
  gvo: ["bukety-gvozdik", "гвоздики"],
  gip: ["bukety-gipsofil", "гипсофила"],
  gor: ["gortenzii", "гортензии"],
  iri: ["bukety-irisov", "ирисы"],
  kus: ["shrub_rose", "кустовая роза"],
  lav: ["lavanda", "лаванда"],
  lil: ["bukety-liliy", "лилии"],
  mat: ["mattiola", "маттиола"],
  orh: ["bukety-orkhidey", "орхидеи"],
  pr: ["pionovidnaya-roza", "пионовидная роза"],
  pio: ["bukety-pionov", "пионы"],
  sta: ["bukety-statits", "статица"],
  suh: ["suhocvety", "сухоцветы"],
  fre: ["freziya", "фрезия"],
  eus: ["eustoma", "эустома"],
};

const POOLS: Record<string, number> = {
  pink: 10,
  red: 7,
  mix: 9,
  peony: 9,
  white: 4,
  box: 5,
  chrys: 4,
  tulip: 5,
  hydr: 4,
};

function imgs(main: string): string[] {
  const [g, n] = main.split("-");
  const total = POOLS[g];
  const start = Number(n);
  const out = [`/img/${main}.jpg`];
  for (let i = 1; i <= 3; i++) out.push(`/img/${g}-${((start - 1 + i) % total) + 1}.jpg`);
  return out;
}

// slug, name, price, oldPrice, image, kind, flowers, popularity, new, roseCount
type Row = [string, string, number, number | 0, string, Kind, string, number, 0 | 1, number?];

const ROWS: Row[] = [
  // розы
  ["buket-iz-21-rozy", "Букет из 21 розы", 2999, 0, "red-1", "roses", "roz", 99, 0, 21],
  ["buket-iz-35-roz", "Букет из 35 роз", 3999, 0, "red-2", "roses", "roz", 96, 0, 35],
  ["buket-iz-51-rozy", "Букет из 51 розы", 5499, 0, "pink-1", "roses", "roz", 95, 0, 51],
  ["buket-iz-101-rozy", "Букет из 101 розы", 7999, 0, "red-4", "roses", "roz", 97, 0, 101],
  ["buket-iz-101-rozy-keniya", "Букет из 101 розы Кения", 5599, 9399, "mix-4", "roses", "roz", 92, 0, 101],
  ["buket-iz-21-rozy-keniya", "Букет из 21 розы Кения", 2599, 3299, "red-6", "roses", "roz", 90, 0, 21],
  ["buket-iz-15-roz-40-sm", "Букет из 15 роз (40 см)", 3299, 0, "pink-2", "roses", "roz", 80, 0, 15],
  ["buket-iz-51-rozy-keniya-miks", "Букет из 51 розы Кения (микс)", 4499, 7499, "mix-2", "roses", "roz", 88, 0, 51],
  ["buket-iz-25-roz", "Букет из 25 роз", 3499, 0, "white-1", "roses", "roz", 84, 0, 25],
  ["buket-iz-41-rozy", "Букет из 41 розы", 4999, 0, "white-2", "roses", "roz", 70, 0, 41],
  ["buket-iz-71-rozy", "Букет из 71 розы", 6499, 0, "pink-4", "roses", "roz", 75, 0, 71],
  ["buket-iz-151-rozy", "Букет из 151 розы", 11999, 0, "red-7", "roses", "roz", 60, 0, 101],
  // букеты
  ["buket-moroznoe-utro", "Букет Морозное утро", 3499, 0, "peony-1", "bouquet", "pr,khr,suh", 94, 1],
  ["buket-minuty-scastya", "Букет Минуты счастья", 4399, 0, "pink-5", "bouquet", "roz,gor", 93, 1],
  ["buket-lunnaya-reka", "Букет Лунная река", 3599, 4499, "mix-1", "bouquet", "iri,alt", 91, 1],
  ["buket-neznyi-polden", "Букет Нежный полдень", 3199, 0, "chrys-1", "bouquet", "rom,khr,gvo", 89, 1],
  ["buket-cvetocnyi-pocelui", "Букет Цветочный поцелуй", 4799, 0, "pink-6", "bouquet", "pr,gor", 87, 1],
  ["buket-simfoniya-cuvstv", "Букет Симфония чувств", 7599, 0, "pink-7", "bouquet", "roz,pr,suh", 86, 1],
  ["buket-predskazanie-scastya", "Букет Предсказание счастья", 3899, 0, "mix-3", "bouquet", "ger,alt,mat", 78, 0],
  ["buket-dzuletta", "Букет Джульетта", 5199, 0, "peony-2", "bouquet", "pio,roz", 82, 0],
  ["buket-cuvstvennoe-priznanie", "Букет Чувственное признание", 4299, 0, "pink-8", "bouquet", "roz,lil", 79, 0],
  ["buket-rozovaya-taina", "Букет Розовая тайна", 3699, 0, "pink-9", "bouquet", "roz,khr,eus", 77, 0],
  ["buket-v-vixre-emocii", "Букет В вихре эмоций", 4999, 0, "mix-5", "bouquet", "ger,pod,roz", 76, 0],
  ["buket-ocarovanie-utra", "Букет Очарование утра", 2899, 0, "tulip-1", "bouquet", "fre,rom", 74, 1],
  ["buket-feierverk-cuvstv", "Букет Фейерверк чувств", 5699, 0, "mix-6", "bouquet", "lil,ger,alt", 73, 0],
  ["buket-rozovyi-eliksir", "Букет Розовый эликсир", 3399, 0, "peony-3", "bouquet", "pio,kus", 85, 0],
  ["buket-cvetocnaya-simfoniya", "Букет Цветочная симфония", 6299, 0, "mix-7", "bouquet", "orh,roz,eus", 72, 0],
  ["buket-1001-noch", "Букет 1001 ночь", 5899, 0, "peony-4", "bouquet", "pio,pr,lav", 71, 0],
  ["buket-dzhumiliya", "Букет Джумилия", 2499, 0, "chrys-2", "bouquet", "rom,khr", 69, 0],
  ["buket-belyi-sarm", "Букет Белый шарм", 3799, 0, "white-3", "bouquet", "roz,gip,sta", 83, 0],
  ["buket-rozovaya-zarya", "Букет Розовая заря", 4599, 0, "pink-10", "bouquet", "roz,gor,gip", 81, 0],
  ["buket-melodiya-dozdya", "Букет Мелодия дождя", 3099, 0, "hydr-1", "bouquet", "gor,lav", 68, 0],
  ["buket-ariel", "Букет Ариэль", 2699, 0, "tulip-2", "bouquet", "fre,mat", 67, 0],
  ["buket-bogema", "Букет Богема", 4199, 0, "mix-8", "bouquet", "suh,pr,lav", 66, 0],
  ["buket-solnce-ryadom", "Букет Солнце рядом", 2199, 0, "chrys-3", "bouquet", "pod,rom,gvo", 65, 0],
  ["buket-diva", "Букет Дива", 5399, 0, "peony-5", "bouquet", "pio,orh", 64, 0],
  ["buket-anabel", "Букет Анабель", 3999, 0, "hydr-2", "bouquet", "gor,roz", 63, 0],
  ["buket-teplo-rassveta", "Букет Тепло рассвета", 3299, 0, "tulip-3", "bouquet", "fre,alt,ger", 62, 0],
  ["buket-yunaya-ledi", "Букет Юная леди", 2999, 0, "tulip-4", "bouquet", "alt,kus", 61, 0],
  ["buket-ledyanaya-neznost", "Букет Ледяная нежность", 3499, 0, "hydr-3", "bouquet", "gor,sta,gip", 59, 0],
  ["buket-goluboi-miraz", "Букет Голубой мираж", 4099, 0, "mix-9", "bouquet", "iri,gor,eus", 58, 0],
  ["buket-vanilnoe-solnce", "Букет Ванильное солнце", 3599, 0, "chrys-4", "bouquet", "khr,pod,ger", 57, 0],
  ["buket-oblacko-cuvstv", "Букет Облачко чувств", 3299, 0, "white-4", "bouquet", "gip,roz,eus", 56, 0],
  ["buket-alpiiskoe-utro", "Букет Альпийское утро", 4699, 0, "peony-6", "bouquet", "pio,fre", 55, 0],
  ["gipsofila-tsvetnaya-3-sht", "Гипсофила цветная (3 шт)", 990, 0, "white-3", "bouquet", "gip", 40, 0],
  ["romashki-25-sht", "Ромашки (25 шт)", 1590, 0, "chrys-3", "bouquet", "rom", 50, 0],
  ["kustovaya-roza-7-sht", "Кустовая роза (7 шт)", 1790, 0, "pink-3", "bouquet", "kus", 45, 0],
  ["buket-gerber-9-sht", "Букет из 9 гербер", 1990, 0, "mix-3", "bouquet", "ger", 52, 0],
  ["buket-podsolnuhov-5-sht", "Букет из 5 подсолнухов", 2290, 0, "chrys-2", "bouquet", "pod", 54, 0],
  // коробки
  ["cvety-v-korobke-flamingo", "Цветы в коробке Фламинго", 8199, 0, "box-1", "box", "roz,gvo,khr", 98, 0],
  ["cvety-v-korobke-nezhnost", "Цветы в коробке Нежность", 5499, 0, "box-2", "box", "roz,pr", 84, 0],
  ["cvety-v-korobke-krasnye-rozy", "Красные розы в коробке", 6999, 0, "box-3", "box", "roz", 83, 0],
  ["cvety-v-korobke-vesenniy", "Цветы в коробке Весенний", 4599, 0, "box-4", "box", "ger,alt", 70, 1],
  ["cvety-v-korobke-rozovoe-oblako", "Цветы в коробке Розовое облако", 5299, 0, "box-5", "box", "roz,gor", 72, 0],
  // корзины
  ["kompoziciya-serebro", "Композиция в металлической банке Серебро", 8899, 0, "mix-6", "basket", "roz,pio,suh", 99, 0],
  ["korzina-letniy-sad", "Корзина Летний сад", 6799, 0, "mix-1", "basket", "ger,pod,roz", 74, 0],
  ["korzina-rozovyy-ray", "Корзина Розовый рай", 7499, 0, "pink-3", "basket", "roz,pr,gor", 82, 0],
  ["korzina-nezhnost", "Корзина Нежность", 5999, 0, "peony-3", "basket", "pio,kus", 66, 0],
];

type GiftRow = [string, string, number, string, string, string];
const GIFTS: GiftRow[] = [
  ["myagkaya-igrushka-mishka", "Мягкая игрушка Мишка", 1290, "🧸", "toys,k-prazdniku", "Плюшевый мишка 25 см — тёплое дополнение к любому букету."],
  ["topper-s-lyubovyu", "Топпер «С любовью»", 290, "💌", "toppery,k-prazdniku", "Декоративный топпер в букет с тёплой надписью."],
  ["vaza-steklyannaya", "Ваза стеклянная", 790, "🏺", "vazy_dlya_cvetov", "Прозрачная ваза высотой 25 см для вашего букета."],
  ["konfety-rafaello", "Конфеты Raffaello", 590, "🍬", "konfety-k-buketam,k-prazdniku", "Коробка конфет 150 г — приятный бонус к цветам."],
  ["otkrytka-s-pozhelaniem", "Открытка с вашим пожеланием", 150, "✉️", "postcards", "Фирменная открытка — напишем ваш текст от руки."],
  ["vozdushnye-shary", "Воздушные шары, 5 шт", 990, "🎈", "vozdushnye_shary,k-prazdniku", "Гелиевые шары с доставкой вместе с букетом."],
  ["nabor-spa", "Подарочный набор SPA", 1990, "🧴", "krasota-i-zdorove,k-prazdniku", "Гель для душа, соль для ванны и свеча в красивой коробке."],
  ["svecha-aromaticheskaya", "Свеча ароматическая", 890, "🕯️", "krasota-i-zdorove,k-prazdniku", "Соевая свеча с ароматом ванили и пиона."],
];

function makeDescription(name: string, kind: Kind, flowers: string[]): string {
  const comp = flowers.length ? flowers.join(", ") : "свежие цветы";
  if (kind === "box") return `${name} — нежная композиция в шляпной коробке. В составе: ${comp}. Флорист соберёт её в день доставки, а перед отправкой мы пришлём фото.`;
  if (kind === "basket") return `${name} — яркая композиция в корзине, готовая к вручению без вазы. В составе: ${comp}. Свежесть цветов гарантируем 5 дней.`;
  if (kind === "roses") return `${name} — классика, которая никогда не выходит из моды. Вы можете выбрать цвет, высоту роз, количество и упаковку. Цветы простоят 5 дней — или мы заменим букет!`;
  return `${name} — авторский букет от наших флористов. В составе: ${comp}. Перед доставкой пришлём фото вашего букета, а цветы простоят 5 дней — или мы заменим его.`;
}

function hash(s: string): number {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
  return h;
}

export const PRODUCTS: Product[] = [
  ...ROWS.map(([slug, name, price, old, img, kind, fl, pop, isNew, rc]): Product => {
    const keys = fl.split(",");
    const flowers = keys.map((k) => FL[k][1]);
    const tags = keys.map((k) => FL[k][0]);
    if (kind === "roses" && !tags.includes("bukety-roz")) tags.push("bukety-roz");
    return {
      slug,
      name,
      price,
      oldPrice: old || undefined,
      kind,
      roseCount: kind === "roses" ? rc : undefined,
      images: imgs(img),
      flowers,
      tags,
      popularity: pop,
      isNew: !!isNew,
      description: makeDescription(name, kind, flowers),
    };
  }),
  ...GIFTS.map(([slug, name, price, emoji, tags, desc], i): Product => ({
    slug,
    name,
    price,
    kind: "gift",
    images: [],
    emoji,
    flowers: [],
    tags: tags.split(","),
    popularity: 30 + i,
    description: desc,
  })),
];

export const BY_SLUG = new Map(PRODUCTS.map((p) => [p.slug, p]));
export const getProduct = (slug: string) => BY_SLUG.get(slug);

const TITLES = menuTitleMap();

export type Category = { slug: string; title: string; h1: string; description: string };

const EXTRA_H1: Record<string, string> = {
  "all-2": "Все букеты в Москве",
  "bukety-roz": "Букеты роз в Москве",
  rozy: "Розы с доставкой в Москве",
  povod: "Цветы на любой повод",
  podarki: "Подарки к букетам",
  cvetochnye_korobki: "Цветы в коробке в Москве",
  kompozicii: "Цветы в корзине в Москве",
  "novogodnyaya-rasprodazha": "Распродажа букетов",
  bestsellers: "Хиты продаж",
  "flowers-new": "Новинки",
  "mothers-day": "Букеты ко Дню матери",
};

export function getCategory(slug: string): Category | null {
  const title = TITLES.get(slug);
  if (!title) return null;
  const h1 = EXTRA_H1[slug] ?? `${title} — купить с доставкой в Москве`;
  return {
    slug,
    title,
    h1,
    description: `Купить «${title.toLowerCase()}» в Москве с быстрой доставкой. Доставка от 2 часов после заказа. Свежие цветы, честные цены, фото букета перед доставкой.`,
  };
}

const flowerSlugs = new Set(Object.values(FL).map((x) => x[0]));
const giftSlugs = new Set(PRODUCTS.filter((p) => p.kind === "gift").flatMap((p) => p.tags));
const nonGift = (p: Product) => p.kind !== "gift";
const roseColorSlugs = new Set(["rozy-belye", "rozy-krasnye", "rozy-kremovye", "malinovye", "rozy-raznocvetnye", "rozy-rozovye"]);

function rawFilter(slug: string, p: Product): boolean {
  const price = p.price;
  switch (slug) {
    case "all-2":
    case "po_vidy_cvetka":
    case "povod":
    case "vybor_pokupateley":
      return nonGift(p);
    case "podarki":
      return p.kind === "gift";
    case "bukety-do-2500_rub":
      return nonGift(p) && price <= 2500;
    case "bukety-2500-4000-rub":
      return nonGift(p) && price >= 2500 && price <= 4000;
    case "bukety-1500-2500-rub":
      return nonGift(p) && price >= 1500 && price <= 2600;
    case "bukety-ot-4000-rub-premium":
      return nonGift(p) && price >= 4000;
    case "cvety-nedorogie":
      return nonGift(p) && price <= 3000;
    case "do-2000-rubley":
      return nonGift(p) && price <= 2000;
    case "do-4000-rubley":
      return nonGift(p) && price <= 4000;
    case "do-7000-rubley":
      return nonGift(p) && price <= 7000;
    case "do-10000-rubley":
      return nonGift(p) && price <= 10000;
    case "novogodnyaya-rasprodazha":
      return !!p.oldPrice;
    case "bestsellers":
      return nonGift(p) && p.popularity >= 85;
    case "flowers-new":
    case "mothers-day":
      return !!p.isNew || (slug === "mothers-day" && p.popularity >= 85 && nonGift(p));
    case "cvetochnye_korobki":
      return p.kind === "box";
    case "kompozicii":
      return p.kind === "basket";
    case "rozy":
      return p.kind === "roses";
    case "rozy-v-korobke":
      return p.kind === "box";
    case "rozy-v-korzine":
      return p.kind === "basket";
    case "rozy-nedorogie":
      return p.kind === "roses" && price <= 3500;
    case "bukety-roz":
      return p.tags.includes("bukety-roz");
    case "euro_bouquets_of_roses":
    case "insta-bukety":
    case "avtorskie-bukety":
      return nonGift(p) && p.kind === "bouquet" && hash(slug + p.slug) % 3 === 0;
  }
  const m = slug.match(/^(?:rozy-)?(\d+)-sht$/);
  if (m) return p.kind === "roses" && (p.roseCount ?? 0) === Number(m[1]);
  if (flowerSlugs.has(slug)) return p.tags.includes(slug);
  if (giftSlugs.has(slug)) return p.tags.includes(slug);
  if (slug.startsWith("rozy-") && (roseColorSlugs.has(slug) || /-sm$/.test(slug) || slug.startsWith("rozy-"))) {
    return p.kind === "roses" && hash(slug + p.slug) % 2 === 0;
  }
  if (slug === "malinovye") return p.kind === "roses" && hash(slug + p.slug) % 2 === 0;
  if (slug === "k-prazdniku") return p.kind === "gift";
  // поводы и получатели
  return nonGift(p) && hash(slug + p.slug) % 4 === 0;
}

export function getCategoryProducts(slug: string): Product[] {
  let list = PRODUCTS.filter((p) => rawFilter(slug, p));
  if (list.length < 4 && !giftSlugs.has(slug) && slug !== "podarki") {
    const extra = PRODUCTS.filter((p) => nonGift(p) && !list.includes(p) && hash(slug + p.slug) % 3 === 0).slice(0, 8 - list.length);
    list = [...list, ...extra];
  }
  return list;
}

export type Sort = "popular" | "price-asc" | "price-desc" | "new";
export function sortProducts(list: Product[], sort: Sort): Product[] {
  const arr = [...list];
  if (sort === "price-asc") arr.sort((a, b) => a.price - b.price);
  else if (sort === "price-desc") arr.sort((a, b) => b.price - a.price);
  else if (sort === "new") arr.sort((a, b) => Number(!!b.isNew) - Number(!!a.isNew) || b.popularity - a.popularity);
  else arr.sort((a, b) => b.popularity - a.popularity);
  return arr;
}

export function searchProducts(q: string): Product[] {
  const s = q.trim().toLowerCase();
  if (!s) return [];
  return PRODUCTS.filter((p) => p.name.toLowerCase().includes(s) || p.flowers.some((f) => f.includes(s)));
}

export const REVIEWS = [
  { name: "Владимир Царев", text: "Пользуюсь приложением уже около 6 лет. Всё доступно, понятно. Цены на цветы отличные. Курьеры как правило приезжают вовремя.", img: "pink-1" },
  { name: "Ирина Б.", text: "Удобный сайт, все понятно. Заказала за 5 минут, оплата без проблем. Курьер вежливый, цветы свежие, не мятые. Супер!", img: "peony-1" },
  { name: "Христина Чигирева", text: "Мой любимый сервис доставки цветов! Уже много лет пользуюсь именно им. Попытки обратиться к конкурентам заканчиваются выводом — лучшие здесь!", img: "mix-1" },
  { name: "Владимир Краморов", text: "Сайт стал для меня спасением в день рождения моей жены. Благодаря удобному интерфейсу я легко выбрал роскошный букет.", img: "pink-6" },
  { name: "Андрей Б.", text: "Покупкой остался доволен. Услуга доставки осуществлена вовремя, качество цветов хорошее. Работают добросовестно.", img: "white-3" },
  { name: "Юлия Мигалина", text: "Доставка сработала на отлично — цветы привезли быстро и в идеальном состоянии. Букет был красивее, чем на фото, свежий и оформленный.", img: "hydr-2" },
  { name: "Илья Кошелев", text: "Отличные букеты! После формирования букета сразу прислали фото в приложении, курьер приехал вовремя. Остались лишь положительные эмоции.", img: "peony-3" },
  { name: "Анна", text: "Хочу выразить благодарность за отличную сборку и доставку букета. Заказала букет и осталась довольна качеством цветов и оформления!", img: "tulip-3" },
];

export const MAP_REVIEWS = [
  { name: "Кирилл И.", date: "16 января 2026 г.", text: "Букет очень красивый, всё понравилось. Курьер — девушка ответственная, перезванивала 2 раза по времени доставки. Спасибо ей. Цветы всегда стоят долго." },
  { name: "Инна Никифорова", date: "14 января 2026 г.", text: "Букет привезли вовремя, цветы свежие. Соответствие заявленному на сайте фото. Прекрасная работа всех служб: оператора call-центра, флориста, курьера." },
  { name: "Михаил Берестнев", date: "10 января 2026 г.", text: "Заказывал маме на день рождения из другого города. Фото пришло заранее, доставили точно в срок. Очень выручили!" },
  { name: "Ольга С.", date: "5 января 2026 г.", text: "Заказываю уже не первый раз. Всегда свежие цветы, красивая упаковка и вежливые курьеры. Рекомендую." },
];

export const FAQ = [
  { q: "Где можно заказать доставку цветов в Москве и Московской области?", a: "Оформить доставку цветов можно на нашем сайте и в мобильном приложении. Выберите букет, укажите адрес и удобное время — остальное мы берём на себя." },
  { q: "Как быстро вы доставляете цветы?", a: "Бесплатная доставка осуществляется в выбранный вами 3-х часовой интервал. Срочная доставка по Москве и МО возможна в течение 2 часов (кроме праздничных дней)." },
  { q: "Пришлёте ли вы фото букета перед доставкой?", a: "Да. После сборки букета мы обязательно отправим вам фото, чтобы вы могли убедиться, что всё соответствует ожиданиям." },
  { q: "Что будет, если цветы завянут раньше срока?", a: "Мы гарантируем свежесть цветов — они простоят 5 дней. Если это не так, мы заменим букет." },
  { q: "Какие способы оплаты доступны?", a: "Банковской картой онлайн, наличными или картой курьеру при получении, а также в рассрочку. Подробности — на странице «Способы оплаты»." },
  { q: "Можно ли заказать доставку в другой город?", a: "Да, мы доставляем цветы по всей России. Выберите город в шапке сайта и оформите заказ." },
];
