export type Kind = "roses" | "bouquet" | "box" | "basket" | "gift";

export type PriceableProduct = {
  price: number;
  kind: Kind;
  roseCount?: number;
};

export type Selection = {
  color?: string;
  height?: number;
  count?: number;
  packaging?: string;
  size?: string;
};

export const ROSE_COLORS = [
  { id: "mix-bright", name: "Яркий микс", hex: "linear-gradient(135deg,#ff3b6b,#ffb703,#fb5607)" },
  { id: "red", name: "Красные", hex: "#c1121f" },
  { id: "mix-soft", name: "Нежный микс", hex: "linear-gradient(135deg,#ffc2d1,#ffe5b4,#fff)" },
  { id: "white", name: "Белые", hex: "#f8f4ef" },
  { id: "cream", name: "Кремовые", hex: "#f3dfb5" },
  { id: "pink", name: "Розовые", hex: "#f783ac" },
  { id: "raspberry", name: "Малиновые", hex: "#d6124f" },
  { id: "peach", name: "Персиковые", hex: "#ffb38a" },
  { id: "burgundy", name: "Бордовые", hex: "#6d0f2b" },
  { id: "orange", name: "Оранжевые", hex: "#f77f00" },
];

export const ROSE_HEIGHTS = [35, 40, 50, 60, 70];
const HEIGHT_MULT: Record<number, number> = { 35: 1, 40: 1.1, 50: 1.3, 60: 1.5, 70: 1.8 };

export const ROSE_COUNTS = [11, 15, 21, 25, 35, 41, 51, 71, 101];

export const PACKAGING = [
  { id: "ribbon", name: "Лента", price: 0 },
  { id: "korean", name: "Корейка", price: 599 },
];

export const SIZES = [
  { id: "s", name: "Стандарт", mult: 1 },
  { id: "m", name: "Большой", mult: 1.3 },
  { id: "l", name: "Премиум", mult: 1.6 },
];

const roseF = (c: number) => 1686 + 62.5 * c;
const round9 = (x: number) => Math.round(x / 100) * 100 - 1;

export function calcPrice(p: PriceableProduct, sel: Selection): number {
  let price = p.price;
  if (p.kind === "roses") {
    const base = p.roseCount ?? 21;
    const count = sel.count ?? base;
    const height = sel.height ?? 35;
    if (count !== base || height !== 35) {
      price = round9((p.price * roseF(count) * (HEIGHT_MULT[height] ?? 1)) / roseF(base));
    }
  } else if (p.kind === "bouquet" || p.kind === "basket" || p.kind === "box") {
    const size = SIZES.find((s) => s.id === (sel.size ?? "s")) ?? SIZES[0];
    if (size.mult !== 1) price = round9(p.price * size.mult);
  }
  if (p.kind !== "gift") {
    const pack = PACKAGING.find((x) => x.id === (sel.packaging ?? "ribbon"));
    price += pack?.price ?? 0;
  }
  return price;
}

export function selectionLabel(p: PriceableProduct, sel: Selection): string {
  const parts: string[] = [];
  if (p.kind === "roses") {
    const c = ROSE_COLORS.find((x) => x.id === sel.color) ?? ROSE_COLORS[0];
    parts.push(`Цвет: ${c.name}`);
    parts.push(`${sel.height ?? 35} см`);
    parts.push(`${sel.count ?? p.roseCount} шт`);
  } else if (p.kind !== "gift") {
    const s = SIZES.find((x) => x.id === (sel.size ?? "s")) ?? SIZES[0];
    parts.push(`Размер: ${s.name}`);
  }
  if (p.kind !== "gift") {
    const pk = PACKAGING.find((x) => x.id === (sel.packaging ?? "ribbon")) ?? PACKAGING[0];
    parts.push(`Упаковка: ${pk.name}`);
  }
  return parts.join(" · ");
}

// ---------- Доставка ----------
export const DISTANCES = [
  { id: "mkad", name: "Доставка в пределах МКАД", price: 0 },
  { id: "out8", name: "Доставка за МКАД до 8 км", price: 300 },
  { id: "far", name: "Доставка за МКАД дальше 8 км", price: 600 },
];

export const TIME_SLOTS = [
  { id: "09-12", name: "09:00 – 12:00", price: 0 },
  { id: "12-15", name: "12:00 – 15:00", price: 0 },
  { id: "15-18", name: "15:00 – 18:00", price: 0 },
  { id: "18-21", name: "18:00 – 21:00", price: 0 },
  { id: "20-23", name: "20:00 – 23:00", price: 499 },
];

export const DELIVERY_OPTIONS = [
  { id: "standard", name: "Выбранный 3-х часовой интервал", price: 0 },
  { id: "urgent", name: "Срочная доставка (в ближайшие 2 часа)", price: 990 },
  { id: "exact", name: "Точное время доставки (+/-15 минут)", price: 1000 },
];

export const PAYMENT_METHODS = [
  { id: "card", name: "Банковской картой онлайн" },
  { id: "cash", name: "Наличными при получении" },
  { id: "courier-card", name: "Картой курьеру" },
  { id: "installment", name: "Рассрочка" },
];

export const PROMOS: Record<string, { type: "percent" | "fixed"; value: number }> = {
  BUKET10: { type: "percent", value: 10 },
  WELCOME: { type: "fixed", value: 300 },
};

export function calcDelivery(distance: string, slot: string, option: string): number {
  const d = DISTANCES.find((x) => x.id === distance)?.price ?? 0;
  const t = TIME_SLOTS.find((x) => x.id === slot)?.price ?? 0;
  const o = DELIVERY_OPTIONS.find((x) => x.id === option)?.price ?? 0;
  return d + t + o;
}

export function calcDiscount(subtotal: number, code: string): number {
  const promo = PROMOS[code.trim().toUpperCase()];
  if (!promo) return 0;
  return promo.type === "percent" ? Math.round((subtotal * promo.value) / 100) : Math.min(promo.value, subtotal);
}

export const formatPrice = (n: number) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, "\u00a0") + "\u00a0₽";
