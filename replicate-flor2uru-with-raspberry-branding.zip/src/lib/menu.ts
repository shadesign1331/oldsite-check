export type MenuLink = { label: string; slug: string };
export type MenuColumn = { title?: string; links: MenuLink[] };
export type MenuItem = {
  key: string;
  label: string;
  slug: string;
  columns: MenuColumn[];
  accent?: boolean;
};

const L = (label: string, slug: string): MenuLink => ({ label, slug });

export const CITIES = [
  "Москва и МО",
  "Санкт-Петербург",
  "Нижний Новгород",
  "Самара",
  "Казань",
  "Уфа",
  "Челябинск",
  "Екатеринбург",
  "Новосибирск",
  "Омск",
  "Волгоград",
  "Воронеж",
];

export const MENU: MenuItem[] = [
  {
    key: "flowers",
    label: "Цветы",
    slug: "all-2",
    columns: [
      {
        title: "Букеты с",
        links: [
          L("Все цветы", "all-2"),
          L("Букеты из роз", "bukety-roz"),
          L("Ромашки", "romashki"),
          L("Герберы", "bukety-gerberov"),
          L("Хризантемы", "bukety-khrizantem"),
          L("Подсолнухи", "podsolnuhi"),
          L("Альстромерии", "bukety-alstromeriy"),
          L("Гвоздики", "bukety-gvozdik"),
          L("Гипсофила", "bukety-gipsofil"),
          L("Гортензии", "gortenzii"),
          L("Ирисы", "bukety-irisov"),
          L("Кустовая роза", "shrub_rose"),
          L("Лаванда", "lavanda"),
          L("Лилии", "bukety-liliy"),
          L("Маттиола", "mattiola"),
          L("Орхидеи", "bukety-orkhidey"),
          L("Пионовидная роза", "pionovidnaya-roza"),
          L("Пионы", "bukety-pionov"),
          L("Статица", "bukety-statits"),
          L("Сухоцветы", "suhocvety"),
          L("Фрезия", "freziya"),
          L("Эустома", "eustoma"),
        ],
      },
      {
        title: "Категории",
        links: [
          L("По виду цветка", "po_vidy_cvetka"),
          L("Букеты до 2500 руб", "bukety-do-2500_rub"),
          L("Распродажа", "novogodnyaya-rasprodazha"),
          L("Букеты от 4000 руб. (премиум)", "bukety-ot-4000-rub-premium"),
          L("Букеты 2500 - 4000 руб.", "bukety-2500-4000-rub"),
          L("Букеты 1500 - 2600 руб.", "bukety-1500-2500-rub"),
          L("Недорогие цветы", "cvety-nedorogie"),
          L("Insta букеты", "insta-bukety"),
          L("Хиты продаж", "bestsellers"),
          L("Новинки", "flowers-new"),
          L("Специальное предложение", "euro_bouquets_of_roses"),
          L("Авторские букеты", "avtorskie-bukety"),
          L("Цветы в корзине", "kompozicii"),
          L("Цветы в коробке", "cvetochnye_korobki"),
          L("До 2000 рублей", "do-2000-rubley"),
          L("До 4000 рублей", "do-4000-rubley"),
          L("До 7000 рублей", "do-7000-rubley"),
          L("До 10000 рублей", "do-10000-rubley"),
          L("Выбор покупателей", "vybor_pokupateley"),
          L("Все категории", "all-2"),
        ],
      },
      {
        title: "Кому",
        links: [
          L("Женщине", "zhenshchine"),
          L("Мужчине", "muzhchine"),
          L("Девушке", "devushke"),
          L("Подруге", "podruge"),
          L("для Любимой", "lyubimoy"),
          L("Маме", "mame"),
          L("Руководителю", "rukovoditelyu"),
          L("Коллеге", "kollege"),
          L("Учителю", "uchitelyu"),
          L("для Невесты", "dlya-nevesty"),
          L("Сестре", "sestre"),
          L("Девочке", "devochke"),
          L("Бабушке", "babushke"),
          L("Все получатели", "all-2"),
        ],
      },
    ],
  },
  {
    key: "occasion",
    label: "Повод",
    slug: "povod",
    columns: [
      {
        links: [
          L("Татьянин день", "tatyanin-den"),
          L("Новоселье", "novoselie"),
          L("1 Сентября", "1-sentyabrya"),
          L("Букеты ко дню матери", "mothers-day"),
          L("14 февраля - День влюбленных", "14-fevralya"),
          L("Выписка из роддома", "vipiska_iz_roddoma"),
          L("23 Февраля", "23-fevralya"),
          L("8 Марта", "8-marta"),
          L("9 мая", "9-maya"),
          L("Выпускной", "vypusknoy"),
          L("Годовщина", "godovshchina"),
        ],
      },
      {
        links: [
          L("День Рождения", "den-rozhdeniya"),
          L("День Учителя", "den-uchitelya"),
          L("Новый Год", "novyy-god"),
          L("Пасха", "pasha"),
          L("Последний звонок", "posledniy-zvonok"),
          L("Повышение", "povyshenie"),
          L("Рождение ребенка", "rozhdenie-rebenka"),
          L("Свадьба", "svadba"),
          L("Свидание", "svidanie"),
          L("Юбилей", "yubiley"),
          L("Торжество", "torzhestvo"),
        ],
      },
    ],
  },
  {
    key: "roses",
    label: "Розы",
    slug: "rozy",
    columns: [
      {
        title: "По количеству",
        links: [
          L("1001 шт", "rozy-1001-sht"),
          L("501 шт", "rozy-501-sht"),
          L("201 роза", "201-sht"),
          L("151 роза", "151-sht"),
          L("101 роза", "rozy-101-sht"),
          L("71 роза", "rozy-71-sht"),
          L("51 роза", "rozy-51-sht"),
          L("41 роза", "rozy-41-sht"),
          L("25 роз", "rozy-25-sht"),
          L("21 роза", "rozy-21-sht"),
          L("15 роз", "rozy-15-sht"),
        ],
      },
      {
        title: "По цвету",
        links: [
          L("Белые розы", "rozy-belye"),
          L("Красные розы", "rozy-krasnye"),
          L("Кремовые розы", "rozy-kremovye"),
          L("Малиновые розы", "malinovye"),
          L("Разноцветные розы", "rozy-raznocvetnye"),
          L("Розовые розы", "rozy-rozovye"),
        ],
      },
      {
        title: "Категории",
        links: [
          L("Розы 40 см", "rozy-40-sm"),
          L("Розы 50 см", "rozy-50-sm"),
          L("Розы 60 см", "rozy-60-sm"),
          L("Розы 70 см", "rozy-70-sm"),
          L("Розы в корзине", "rozy-v-korzine"),
          L("Розы в коробке", "rozy-v-korobke"),
          L("Розы для любимой", "rozy-dlya-lyubimoy"),
          L("Розы маме", "rozy-mame"),
          L("Розы недорогие", "rozy-nedorogie"),
          L("Розы пионовидные", "rozy-pionovidnye"),
          L("Розы пионовидные (моно)", "rozy-pionovidnye-mono"),
          L("Все категории", "rozy"),
        ],
      },
    ],
  },
  {
    key: "gifts",
    label: "Подарки",
    slug: "podarki",
    columns: [
      {
        title: "К празднику",
        links: [
          L("К празднику", "k-prazdniku"),
          L("Красота и здоровье", "krasota-i-zdorove"),
          L("Мягкие игрушки", "toys"),
          L("Топперы", "toppery"),
          L("Вазы к букетам", "vazy_dlya_cvetov"),
          L("Конфеты к букетам", "konfety-k-buketam"),
          L("Открытки", "postcards"),
          L("Воздушные шары", "vozdushnye_shary"),
        ],
      },
    ],
  },
  { key: "boxes", label: "Цветы в коробке", slug: "cvetochnye_korobki", columns: [] },
  { key: "baskets", label: "Цветы в корзине", slug: "kompozicii", columns: [] },
  { key: "sale", label: "SALE", slug: "novogodnyaya-rasprodazha", columns: [], accent: true },
];

export function menuTitleMap(): Map<string, string> {
  const m = new Map<string, string>();
  for (const item of MENU) {
    if (!m.has(item.slug)) m.set(item.slug, item.label);
    for (const col of item.columns)
      for (const l of col.links) if (!m.has(l.slug) || l.label !== "Все категории") m.set(l.slug, l.label);
  }
  m.set("all-2", "Все цветы");
  m.set("rozy", "Розы");
  m.set("povod", "Повод");
  m.set("podarki", "Подарки");
  m.set("po_vidy_cvetka", "По виду цветка");
  return m;
}
