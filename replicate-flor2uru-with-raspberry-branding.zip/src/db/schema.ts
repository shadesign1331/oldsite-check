import {
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export type OrderItem = {
  slug: string;
  name: string;
  image: string | null;
  qty: number;
  price: number;
  options: Record<string, string | number>;
  optionsLabel: string;
};

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  number: varchar("number", { length: 16 }).notNull().unique(),
  customerName: text("customer_name").notNull(),
  customerPhone: varchar("customer_phone", { length: 32 }).notNull(),
  recipientName: text("recipient_name").notNull(),
  recipientPhone: varchar("recipient_phone", { length: 32 }).notNull(),
  city: text("city").notNull(),
  street: text("street").notNull(),
  house: varchar("house", { length: 32 }).notNull(),
  flat: varchar("flat", { length: 32 }).default("").notNull(),
  comment: text("comment").default("").notNull(),
  cardText: text("card_text").default("").notNull(),
  deliveryDate: varchar("delivery_date", { length: 16 }).notNull(),
  deliveryTime: varchar("delivery_time", { length: 32 }).notNull(),
  distance: varchar("distance", { length: 16 }).notNull(),
  deliveryOption: varchar("delivery_option", { length: 16 }).notNull(),
  paymentMethod: varchar("payment_method", { length: 16 }).notNull(),
  promoCode: varchar("promo_code", { length: 32 }).default("").notNull(),
  items: jsonb("items").$type<OrderItem[]>().notNull(),
  subtotal: integer("subtotal").notNull(),
  discount: integer("discount").notNull(),
  deliveryPrice: integer("delivery_price").notNull(),
  total: integer("total").notNull(),
  bonuses: integer("bonuses").notNull(),
  status: varchar("status", { length: 24 }).default("new").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type OrderRow = typeof orders.$inferSelect;
