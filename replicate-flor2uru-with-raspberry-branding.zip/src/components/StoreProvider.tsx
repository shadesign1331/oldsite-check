"use client";

import Link from "next/link";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { Selection } from "@/lib/pricing";

export type CartItem = {
  key: string;
  slug: string;
  name: string;
  image: string | null;
  emoji?: string;
  price: number;
  qty: number;
  options: Selection;
  optionsLabel: string;
};

export type User = { name: string; phone: string };

type Store = {
  ready: boolean;
  cart: CartItem[];
  count: number;
  total: number;
  add: (item: Omit<CartItem, "qty">, qty?: number) => void;
  setQty: (key: string, qty: number) => void;
  remove: (key: string) => void;
  clear: () => void;
  favs: string[];
  toggleFav: (slug: string) => void;
  city: string;
  setCity: (c: string) => void;
  user: User | null;
  login: (u: User) => void;
  logout: () => void;
  modal: null | "login" | "city" | "search";
  openModal: (m: "login" | "city" | "search") => void;
  closeModal: () => void;
};

const Ctx = createContext<Store | null>(null);

export function useStore(): Store {
  const c = useContext(Ctx);
  if (!c) throw new Error("StoreProvider missing");
  return c;
}

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [favs, setFavs] = useState<string[]>([]);
  const [city, setCityState] = useState("Москва и МО");
  const [user, setUser] = useState<User | null>(null);
  const [modal, setModal] = useState<Store["modal"]>(null);
  const [toast, setToast] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    setCart(load<CartItem[]>("bvo_cart", []));
    setFavs(load<string[]>("bvo_favs", []));
    setCityState(load<string>("bvo_city", "Москва и МО"));
    setUser(load<User | null>("bvo_user", null));
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem("bvo_cart", JSON.stringify(cart));
  }, [cart, ready]);
  useEffect(() => {
    if (ready) localStorage.setItem("bvo_favs", JSON.stringify(favs));
  }, [favs, ready]);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setToast(null), 3200);
  }, []);

  const add: Store["add"] = useCallback(
    (item, qty = 1) => {
      setCart((prev) => {
        const found = prev.find((x) => x.key === item.key);
        if (found) return prev.map((x) => (x.key === item.key ? { ...x, qty: Math.min(99, x.qty + qty) } : x));
        return [...prev, { ...item, qty }];
      });
      showToast(`«${item.name}» добавлен в корзину`);
    },
    [showToast],
  );

  const value = useMemo<Store>(
    () => ({
      ready,
      cart,
      count: cart.reduce((s, i) => s + i.qty, 0),
      total: cart.reduce((s, i) => s + i.qty * i.price, 0),
      add,
      setQty: (key, qty) =>
        setCart((prev) => (qty <= 0 ? prev.filter((x) => x.key !== key) : prev.map((x) => (x.key === key ? { ...x, qty: Math.min(99, qty) } : x)))),
      remove: (key) => setCart((prev) => prev.filter((x) => x.key !== key)),
      clear: () => setCart([]),
      favs,
      toggleFav: (slug) => {
        setFavs((prev) => (prev.includes(slug) ? prev.filter((s) => s !== slug) : [...prev, slug]));
      },
      city,
      setCity: (c) => {
        setCityState(c);
        localStorage.setItem("bvo_city", JSON.stringify(c));
        setModal(null);
      },
      user,
      login: (u) => {
        setUser(u);
        localStorage.setItem("bvo_user", JSON.stringify(u));
        setModal(null);
      },
      logout: () => {
        setUser(null);
        localStorage.removeItem("bvo_user");
      },
      modal,
      openModal: setModal,
      closeModal: () => setModal(null),
    }),
    [ready, cart, favs, city, user, modal, add],
  );

  return (
    <Ctx.Provider value={value}>
      {children}
      {toast && (
        <div className="fade-up fixed right-4 bottom-4 z-[100] flex max-w-[360px] items-center gap-3 rounded-2xl bg-wine px-5 py-4 text-sm text-white shadow-2xl">
          <span className="text-lg">✓</span>
          <span className="flex-1">{toast}</span>
          <Link href="/personal/basket" className="font-semibold whitespace-nowrap text-brand-tint underline" onClick={() => setToast(null)}>
            В корзину
          </Link>
        </div>
      )}
    </Ctx.Provider>
  );
}
