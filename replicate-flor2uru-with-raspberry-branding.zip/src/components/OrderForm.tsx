"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { useStore } from "./StoreProvider";
import {
  DELIVERY_OPTIONS,
  DISTANCES,
  PAYMENT_METHODS,
  PROMOS,
  TIME_SLOTS,
  calcDelivery,
  calcDiscount,
  formatPrice,
} from "@/lib/pricing";
import { formatPhone, isPhoneValid } from "@/lib/phone";

const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const CARD_SAMPLES = ["С Днём рождения! Пусть каждый день будет как праздник 🌷", "Люблю тебя! Ты — самое лучшее, что есть в моей жизни", "Спасибо тебе за всё, мамочка! С праздником!"];

function Section({ n, title, children }: { n: number; title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-3xl border border-line bg-white p-5 md:p-7">
      <h2 className="mb-5 flex items-center gap-3 text-xl font-bold">
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand text-sm text-white">{n}</span>
        {title}
      </h2>
      {children}
    </section>
  );
}

function Radio({ checked, onChange, label, price }: { checked: boolean; onChange: () => void; label: string; price?: number }) {
  return (
    <label
      className={`flex cursor-pointer items-center justify-between gap-3 rounded-xl border-2 px-4 py-3 text-sm transition-colors ${checked ? "border-brand bg-brand-soft" : "border-line hover:border-brand/40"}`}
    >
      <span className="flex items-center gap-3">
        <input type="radio" checked={checked} onChange={onChange} className="h-4 w-4 accent-[#dc1458]" />
        {label}
      </span>
      {price !== undefined && <span className="font-semibold whitespace-nowrap">{price > 0 ? `+ ${formatPrice(price)}` : "бесплатно"}</span>}
    </label>
  );
}

export function OrderForm() {
  const { cart, ready, total, clear, city, user } = useStore();
  const router = useRouter();
  const [f, setF] = useState({
    customerName: "",
    customerPhone: "",
    recipientName: "",
    recipientPhone: "",
    self: true,
    street: "",
    house: "",
    flat: "",
    comment: "",
    cardText: "",
    date: "",
    time: "12-15",
    distance: "mkad",
    option: "standard",
    payment: "card",
  });
  const [dates, setDates] = useState<{ value: string; label: string }[]>([]);
  const [promo, setPromo] = useState("");
  const [appliedPromo, setAppliedPromo] = useState("");
  const [promoMsg, setPromoMsg] = useState("");
  const [errors, setErrors] = useState<Record<string, boolean>>({});
  const [busy, setBusy] = useState(false);
  const [serverError, setServerError] = useState("");

  useEffect(() => {
    const now = new Date();
    const list = [0, 1, 2].map((i) => {
      const d = new Date(now.getTime() + i * 86400000);
      const label = (i === 0 ? "Сегодня" : i === 1 ? "Завтра" : "Послезавтра") + ", " + d.toLocaleDateString("ru-RU", { day: "numeric", month: "long" });
      return { value: iso(d), label };
    });
    setDates(list);
    let draft: { name?: string; phone?: string } = {};
    try {
      draft = JSON.parse(localStorage.getItem("bvo_draft") || "{}");
    } catch {}
    setF((s) => ({ ...s, date: s.date || list[1].value, customerName: draft.name ?? user?.name ?? "", customerPhone: draft.phone ?? user?.phone ?? "" }));
  }, [user]);

  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((s) => ({ ...s, [k]: v }));

  const delivery = useMemo(() => calcDelivery(f.distance, f.time, f.option), [f.distance, f.time, f.option]);
  const discount = useMemo(() => calcDiscount(total, appliedPromo), [total, appliedPromo]);
  const grand = total - discount + delivery;
  const bonus = Math.round((total - discount) * 0.1);

  if (!ready) return <div className="h-64" />;
  if (!cart.length)
    return (
      <div className="py-20 text-center">
        <p className="mb-6 text-lg text-muted">В корзине пока ничего нет.</p>
        <Link href="/catalog/all-2" className="btn-brand inline-flex h-12 items-center px-8">
          Перейти в каталог
        </Link>
      </div>
    );

  const applyPromo = () => {
    const code = promo.trim().toUpperCase();
    if (PROMOS[code]) {
      setAppliedPromo(code);
      setPromoMsg(`Промокод применён: ${PROMOS[code].type === "percent" ? `-${PROMOS[code].value}%` : `-${formatPrice(PROMOS[code].value)}`}`);
    } else {
      setAppliedPromo("");
      setPromoMsg("Такого промокода нет. Попробуйте BUKET10");
    }
  };

  const submit = async () => {
    const e: Record<string, boolean> = {
      customerName: f.customerName.trim().length < 2,
      customerPhone: !isPhoneValid(f.customerPhone),
      street: !f.street.trim(),
      house: !f.house.trim(),
      recipientName: !f.self && f.recipientName.trim().length < 2,
      recipientPhone: !f.self && !isPhoneValid(f.recipientPhone),
    };
    setErrors(e);
    if (Object.values(e).some(Boolean)) {
      setServerError("Проверьте выделенные поля");
      return;
    }
    setServerError("");
    setBusy(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: f.customerName,
          customerPhone: f.customerPhone,
          recipientName: f.self ? f.customerName : f.recipientName,
          recipientPhone: f.self ? f.customerPhone : f.recipientPhone,
          city,
          street: f.street,
          house: f.house,
          flat: f.flat,
          comment: f.comment,
          cardText: f.cardText,
          deliveryDate: f.date,
          deliveryTime: f.time,
          distance: f.distance,
          deliveryOption: f.option,
          paymentMethod: f.payment,
          promoCode: appliedPromo,
          items: cart.map((c) => ({ slug: c.slug, qty: c.qty, options: c.options })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Ошибка оформления");
      clear();
      localStorage.removeItem("bvo_draft");
      router.push(`/order/${data.number}`);
    } catch (err) {
      setServerError(err instanceof Error ? err.message : "Ошибка оформления");
      setBusy(false);
    }
  };

  const cls = (k: string) => `input ${errors[k] ? "error" : ""}`;

  return (
    <div className="grid items-start gap-8 lg:grid-cols-[1fr_380px]">
      <div className="space-y-5">
        <Section n={1} title="Контакты">
          <div className="grid gap-3 md:grid-cols-2">
            <input className={cls("customerName")} placeholder="Ваше имя" value={f.customerName} onChange={(e) => set("customerName", e.target.value)} />
            <input className={cls("customerPhone")} placeholder="+7(___)___-__-__" inputMode="tel" value={f.customerPhone} onChange={(e) => set("customerPhone", formatPhone(e.target.value))} />
          </div>
          <label className="mt-4 flex cursor-pointer items-center gap-2 text-sm">
            <input type="checkbox" checked={f.self} onChange={(e) => set("self", e.target.checked)} className="h-5 w-5 accent-[#dc1458]" />
            Получатель — я
          </label>
          {!f.self && (
            <div className="fade-up mt-3 grid gap-3 md:grid-cols-2">
              <input className={cls("recipientName")} placeholder="Имя получателя" value={f.recipientName} onChange={(e) => set("recipientName", e.target.value)} />
              <input className={cls("recipientPhone")} placeholder="Телефон получателя" inputMode="tel" value={f.recipientPhone} onChange={(e) => set("recipientPhone", formatPhone(e.target.value))} />
            </div>
          )}
        </Section>

        <Section n={2} title="Адрес доставки">
          <div className="mb-3 text-sm text-muted">Город: <b className="text-ink">{city}</b></div>
          <div className="grid gap-3 md:grid-cols-[1fr_120px_120px]">
            <input className={cls("street")} placeholder="Улица" value={f.street} onChange={(e) => set("street", e.target.value)} />
            <input className={cls("house")} placeholder="Дом" value={f.house} onChange={(e) => set("house", e.target.value)} />
            <input className="input" placeholder="Квартира" value={f.flat} onChange={(e) => set("flat", e.target.value)} />
          </div>
          <div className="mt-4 grid gap-2">
            {DISTANCES.map((d) => (
              <Radio key={d.id} checked={f.distance === d.id} onChange={() => set("distance", d.id)} label={d.name} price={d.price} />
            ))}
          </div>
        </Section>

        <Section n={3} title="Дата и время доставки">
          <div className="mb-4 flex flex-wrap gap-2">
            {dates.map((d) => (
              <button
                key={d.value}
                onClick={() => set("date", d.value)}
                className={`rounded-xl border-2 px-4 py-2.5 text-sm ${f.date === d.value ? "border-brand bg-brand-soft font-semibold" : "border-line hover:border-brand/40"}`}
              >
                {d.label}
              </button>
            ))}
            <input type="date" min={dates[0]?.value} value={f.date} onChange={(e) => set("date", e.target.value)} className="h-[44px] rounded-xl border-2 border-line px-3 text-sm outline-none focus:border-brand" />
          </div>
          <div className="grid gap-2 md:grid-cols-2">
            {TIME_SLOTS.map((t) => (
              <Radio key={t.id} checked={f.time === t.id} onChange={() => set("time", t.id)} label={t.name} price={t.price} />
            ))}
          </div>
          <div className="mt-4 grid gap-2">
            {DELIVERY_OPTIONS.map((d) => (
              <Radio key={d.id} checked={f.option === d.id} onChange={() => set("option", d.id)} label={d.name} price={d.price} />
            ))}
          </div>
          <p className="mt-3 text-xs text-muted">Если адрес за МКАД, интервал доставки увеличивается на час. Срочная доставка недоступна в праздничные дни.</p>
        </Section>

        <Section n={4} title="Открытка и комментарий">
          <textarea className="input" rows={3} placeholder="Текст открытки — напишем от руки" value={f.cardText} onChange={(e) => set("cardText", e.target.value)} />
          <div className="mt-2 flex flex-wrap gap-2">
            {CARD_SAMPLES.map((s) => (
              <button key={s} onClick={() => set("cardText", s)} className="rounded-full bg-brand-soft px-3 py-1.5 text-xs hover:bg-brand-tint">
                {s.length > 38 ? s.slice(0, 38) + "…" : s}
              </button>
            ))}
          </div>
          <textarea className="input mt-3" rows={2} placeholder="Комментарий курьеру (домофон, этаж, как пройти)" value={f.comment} onChange={(e) => set("comment", e.target.value)} />
        </Section>

        <Section n={5} title="Способ оплаты">
          <div className="grid gap-2 md:grid-cols-2">
            {PAYMENT_METHODS.map((m) => (
              <Radio key={m.id} checked={f.payment === m.id} onChange={() => set("payment", m.id)} label={m.name} />
            ))}
          </div>
        </Section>
      </div>

      <aside className="sticky top-[76px] rounded-3xl border border-line bg-white p-6">
        <h2 className="mb-4 text-2xl font-bold">Ваш заказ</h2>
        <ul className="mb-4 max-h-[260px] space-y-3 overflow-y-auto">
          {cart.map((c) => (
            <li key={c.key} className="flex gap-3 text-sm">
              <div className="h-14 w-12 shrink-0 overflow-hidden rounded-lg bg-[#f6f3f4]">
                {c.image ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={c.image} alt="" className="h-full w-full object-cover" />
                ) : (
                  <div className="flex h-full items-center justify-center text-2xl">{c.emoji}</div>
                )}
              </div>
              <div className="flex-1 leading-tight">
                <div className="font-medium">{c.name}</div>
                <div className="text-xs text-muted">{c.qty} × {formatPrice(c.price)}</div>
              </div>
              <b>{formatPrice(c.price * c.qty)}</b>
            </li>
          ))}
        </ul>
        <div className="mb-4 flex gap-2">
          <input className="input !h-11 !text-sm" placeholder="Промокод" value={promo} onChange={(e) => setPromo(e.target.value)} />
          <button onClick={applyPromo} className="h-11 shrink-0 rounded-xl bg-wine px-4 text-sm font-semibold text-white hover:bg-ink">
            Применить
          </button>
        </div>
        {promoMsg && <p className={`-mt-2 mb-3 text-xs ${appliedPromo ? "text-green-600" : "text-[#e5484d]"}`}>{promoMsg}</p>}
        <dl className="space-y-2 border-t border-line pt-4 text-sm">
          <div className="flex justify-between"><dt className="text-muted">Товары</dt><dd>{formatPrice(total)}</dd></div>
          {discount > 0 && <div className="flex justify-between text-green-600"><dt>Скидка по промокоду</dt><dd>− {formatPrice(discount)}</dd></div>}
          <div className="flex justify-between"><dt className="text-muted">Доставка</dt><dd>{delivery > 0 ? formatPrice(delivery) : "Бесплатно"}</dd></div>
          <div className="flex justify-between pt-2 text-lg"><dt className="font-bold">Итого</dt><dd className="text-2xl font-bold">{formatPrice(grand)}</dd></div>
          <div className="flex justify-between text-muted"><dt>Вернем баллами</dt><dd className="font-semibold text-[#e5a100]">{formatPrice(bonus)}</dd></div>
        </dl>
        {serverError && <p className="mt-4 rounded-lg bg-[#fff5f5] p-3 text-sm text-[#e5484d]">{serverError}</p>}
        <button disabled={busy} onClick={submit} className="btn-brand mt-5 h-[56px] w-full text-lg disabled:opacity-60">
          {busy ? "Оформляем…" : f.payment === "card" ? `Оплатить ${formatPrice(grand)}` : "Оформить заказ"}
        </button>
        <p className="mt-3 text-[11px] leading-snug text-muted">Нажимая кнопку, вы соглашаетесь с Офертой и обработкой персональных данных.</p>
      </aside>
    </div>
  );
}
