"use client";

import { usePathname, useRouter } from "next/navigation";

const OPTIONS = [
  ["popular", "Популярные"],
  ["price-asc", "Сначала дешевле"],
  ["price-desc", "Сначала дороже"],
  ["new", "Новинки"],
];

export function SortSelect({ value }: { value: string }) {
  const router = useRouter();
  const path = usePathname();
  return (
    <select
      value={value}
      onChange={(e) => router.push(`${path}?sort=${e.target.value}`)}
      className="h-9 cursor-pointer rounded-lg bg-ink px-3 text-sm text-white outline-none"
    >
      {OPTIONS.map(([v, l]) => (
        <option key={v} value={v}>
          {l}
        </option>
      ))}
    </select>
  );
}
