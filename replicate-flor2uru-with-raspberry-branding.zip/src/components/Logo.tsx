import Link from "next/link";

export function TulipMark({ className = "h-11 w-auto" }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 100" className={className} aria-hidden="true">
      <path
        fillRule="evenodd"
        fill="#f40f48"
        d="M4 22 C4 19.5 6 18 8.5 18 C20 18 30 22 35.5 30 C38.5 20 44 12.5 50 8 C51 7.2 52.4 7.2 53.4 8 C60.5 13 66.5 20.5 67.5 31.5 C72.5 25 80 19.5 88.5 18 C90.5 17.8 91.5 18.6 91.8 20.5 C94 40 93 57 82.5 68.5 C74.5 77.5 62.5 83 48 83.5 L40 84 L25 93 C22.5 94.4 20.5 93 21.6 90.6 L27 79.5 C12 72 4 60 4 44 Z M67.5 41 C67.5 52 61 60.5 53 67 L49 71 C47.5 62.5 47.5 56 51 51 C55 45.5 62 42 67 38.5 Z"
      />
    </svg>
  );
}

export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link href="/" className={`inline-flex items-center gap-2.5 ${className}`} aria-label="Букет в ответ — на главную">
      <TulipMark />
      <span className="text-[22px] leading-[0.95] font-black tracking-tight text-wine">
        Букет
        <br />в ответ
      </span>
    </Link>
  );
}
