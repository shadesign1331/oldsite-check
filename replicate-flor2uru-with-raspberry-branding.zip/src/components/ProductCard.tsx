"use client";

import Link from "next/link";
import type { Product } from "@/lib/catalog";
import { buildCartItem, defaultSelection } from "@/lib/cartItem";
import { formatPrice } from "@/lib/pricing";
import { useStore } from "./StoreProvider";
import { HeartIcon } from "./Icons";

export function FavButton({ slug, className = "" }: { slug: string; className?: string }) {
  const { favs, toggleFav } = useStore();
  const on = favs.includes(slug);
  return (
    <button
      aria-label={on ? "Убрать из избранного" : "Добавить в избранное"}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleFav(slug);
      }}
      className={`flex h-9 w-9 items-center justify-center rounded-lg bg-white/80 text-muted backdrop-blur transition-colors hover:text-brand ${on ? "!text-brand" : ""} ${className}`}
    >
      <HeartIcon className="h-5 w-5" filled={on} />
    </button>
  );
}

export function ProductImage({ p, className = "" }: { p: Product; className?: string }) {
  if (p.images[0])
    return (
      // eslint-disable-next-line @next/next/no-img-element
      <img src={p.images[0]} alt={p.name} loading="lazy" className={`h-full w-full object-cover transition-transform duration-500 group-hover:scale-105 ${className}`} />
    );
  return (
    <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-brand-soft to-brand-tint text-7xl">
      {p.emoji}
    </div>
  );
}

export function ProductCard({ p }: { p: Product }) {
  const { add } = useStore();
  const discount = p.oldPrice ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;
  return (
    <div className="group card-shadow flex flex-col overflow-hidden rounded-2xl bg-white">
      <Link href={`/product/${p.slug}`} className="relative block aspect-square overflow-hidden bg-[#f6f3f4]">
        <ProductImage p={p} />
        <FavButton slug={p.slug} className="absolute top-2.5 right-2.5" />
        {p.isNew && <span className="absolute top-2.5 left-2.5 rounded-md bg-brand px-2 py-0.5 text-[11px] font-bold text-white">NEW</span>}
      </Link>
      <div className="flex flex-1 flex-col p-3">
        <Link href={`/product/${p.slug}`} className="min-h-[40px] text-[15px] leading-snug hover:text-brand">
          {p.name}
        </Link>
        <div className="mt-auto flex items-end justify-between pt-3">
          <div className="leading-tight">
            {p.oldPrice && (
              <div className="mb-0.5 flex items-center gap-1.5">
                <span className="text-xs text-muted line-through decoration-brand">{formatPrice(p.oldPrice)}</span>
                <span className="rounded-md bg-[#e11d48] px-1.5 py-0.5 text-[10px] font-semibold text-white">-{discount}%</span>
              </div>
            )}
            <div className="text-xl font-bold">{formatPrice(p.price)}</div>
          </div>
          <button onClick={() => add(buildCartItem(p, defaultSelection(p)))} className="btn-brand h-[34px] px-5 text-sm">
            Купить
          </button>
        </div>
      </div>
    </div>
  );
}

export function ProductGrid({ items }: { items: Product[] }) {
  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-3 md:gap-5 lg:grid-cols-4">
      {items.map((p) => (
        <ProductCard key={p.slug} p={p} />
      ))}
    </div>
  );
}
