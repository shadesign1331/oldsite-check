"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { Logo } from "./Logo";
import { useStore } from "./StoreProvider";
import { MENU, CITIES } from "@/lib/menu";
import {
  CartIcon,
  ChevronDown,
  ClockIcon,
  CloseIcon,
  HeartIcon,
  NavIcon,
  PinIcon,
  SearchIcon,
  UserIcon,
} from "./Icons";

const TOP_LINKS = [
  { label: "Оплата", href: "/sposoby-oplaty" },
  { label: "Доставка", href: "/dostavka" },
  { label: "Блог", href: "/blog" },
  { label: "О нас", href: "/o-kompanii" },
  { label: "Отзывы", href: "/reviews", badge: "7 757" },
  { label: "Узнать статус заказа", href: "/order-status" },
];

export function Header() {
  const { count, favs, city, user, openModal, logout } = useStore();
  const [banner, setBanner] = useState(true);
  const [active, setActive] = useState<string | null>(null);
  const [userMenu, setUserMenu] = useState(false);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const userRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (userRef.current && !userRef.current.contains(e.target as Node)) setUserMenu(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const enter = (key: string) => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setActive(key);
  };
  const leave = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    closeTimer.current = setTimeout(() => setActive(null), 120);
  };

  return (
    <>
      {banner && (
        <div className="relative bg-brand text-white">
          <div className="flex h-9 items-center justify-center px-10 text-center text-[15px] font-semibold">
            Цветы простоят — 5 дней! Или заменим букет!
          </div>
          <button aria-label="Закрыть" onClick={() => setBanner(false)} className="absolute top-1/2 right-4 -translate-y-1/2 opacity-90 hover:opacity-100">
            <CloseIcon />
          </button>
        </div>
      )}

      <div className="hidden bg-[#f7f5f6] md:block">
        <div className="wrap flex h-11 items-center gap-6 text-sm">
          {TOP_LINKS.map((l) => (
            <Link key={l.href} href={l.href} className="hover:text-brand">
              {l.label}
              {l.badge && (
                <span className="ml-1 text-muted">
                  • {l.badge}
                </span>
              )}
            </Link>
          ))}
          <a href="tel:88006004360" className="ml-auto font-semibold hover:text-brand">
            8 800 600-43-60
          </a>
        </div>
      </div>

      <div className="border-b border-line bg-white">
        <div className="wrap flex h-[76px] items-center gap-4 md:h-[88px] md:gap-8">
          <Logo className="shrink-0" />
          <button
            onClick={() => openModal("city")}
            className="hidden h-12 min-w-[216px] items-center gap-3 rounded-xl bg-brand-soft px-4 text-left md:flex"
          >
            <PinIcon className="h-4 w-4 text-brand" />
            <span className="flex-1 leading-tight">
              <span className="block text-[11px] text-brand">Доставка цветов в</span>
              <span className="block text-sm font-medium">{city}</span>
            </span>
            <ChevronDown className="h-4 w-4 text-brand" />
          </button>
          <div className="hidden items-center gap-3 text-xs leading-tight lg:flex">
            <ClockIcon className="h-6 w-6" />
            <span>
              Работаем ежедневно
              <br />
              24 часа в сутки
            </span>
          </div>

          <div className="ml-auto flex items-center gap-1 md:gap-3">
            <HeaderAction href="/favourites" label="Избранное" icon={<HeartIcon className="h-6 w-6" />} badge={favs.length} />
            <HeaderAction href="/personal/basket" label="Корзина" icon={<CartIcon className="h-6 w-6" />} badge={count} />
            <div className="relative" ref={userRef}>
              {user ? (
                <button onClick={() => setUserMenu((v) => !v)} className="flex w-[84px] flex-col items-center gap-1 text-sm text-muted hover:text-brand">
                  <UserIcon className="h-6 w-6 text-brand" />
                  <span className="max-w-full truncate">{user.name || "Профиль"}</span>
                </button>
              ) : (
                <button onClick={() => openModal("login")} className="flex w-[64px] flex-col items-center gap-1 text-sm text-muted hover:text-brand md:w-[84px]">
                  <UserIcon className="h-6 w-6" />
                  <span>Войти</span>
                </button>
              )}
              {user && userMenu && (
                <div className="fade-up absolute top-full right-0 z-50 mt-2 w-56 rounded-2xl bg-white p-2 text-sm shadow-2xl ring-1 ring-black/5">
                  <div className="px-3 py-2 text-xs text-muted">{user.phone}</div>
                  <Link onClick={() => setUserMenu(false)} href="/order-status" className="block rounded-lg px-3 py-2 hover:bg-brand-soft">
                    Ваши бонусы
                  </Link>
                  <Link onClick={() => setUserMenu(false)} href="/order-status" className="block rounded-lg px-3 py-2 hover:bg-brand-soft">
                    История заказов
                  </Link>
                  <Link onClick={() => setUserMenu(false)} href="/favourites" className="block rounded-lg px-3 py-2 hover:bg-brand-soft">
                    Избранное
                  </Link>
                  <button
                    onClick={() => {
                      logout();
                      setUserMenu(false);
                    }}
                    className="block w-full rounded-lg px-3 py-2 text-left hover:bg-brand-soft"
                  >
                    Выйти из аккаунта
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <nav className="sticky top-0 z-40 bg-white shadow-[0_4px_14px_rgba(60,10,30,0.06)]" onMouseLeave={leave}>
        <div className="wrap flex h-[60px] items-center gap-5 overflow-x-auto no-scrollbar md:overflow-visible">
          {MENU.map((item, i) => (
            <div key={item.key} className="flex shrink-0 items-center" onMouseEnter={() => (item.columns.length ? enter(item.key) : setActive(null))}>
              {i === 1 && <span className="mr-5 -ml-0 hidden h-5 w-px bg-line md:block" />}
              <Link
                href={`/catalog/${item.slug}`}
                onClick={() => setActive(null)}
                className={`flex items-center gap-2 text-sm font-medium whitespace-nowrap transition-colors ${
                  item.accent ? "text-brand" : active === item.key || (i === 0 && !active) ? "text-brand" : "text-ink hover:text-brand"
                }`}
              >
                <NavIcon name={item.key} className={`h-[18px] w-[18px] ${item.accent || i === 0 ? "text-brand" : ""}`} />
                {item.label}
              </Link>
            </div>
          ))}
          <button onClick={() => openModal("search")} className="ml-auto flex shrink-0 items-center gap-2 text-sm font-medium hover:text-brand">
            <SearchIcon />
            <span className="hidden sm:inline">Поиск по сайту</span>
          </button>
        </div>

        {active && (
          <div className="absolute inset-x-0 top-full hidden border-t border-line bg-white shadow-[0_18px_30px_rgba(60,10,30,0.12)] md:block" onMouseEnter={() => enter(active)}>
            <div className="wrap fade-up flex max-h-[70vh] gap-12 overflow-y-auto py-7">
              {MENU.find((m) => m.key === active)?.columns.map((col, ci) => (
                <div key={ci} className={`min-w-[190px] ${col.links.length > 14 ? "columns-2 gap-10" : ""}`}>
                  {col.title && <div className="mb-3 text-base font-bold text-wine">{col.title}</div>}
                  <ul className="space-y-2.5 text-sm">
                    {col.links.map((l) => (
                      <li key={l.slug + l.label} className="break-inside-avoid">
                        <Link href={`/catalog/${l.slug}`} onClick={() => setActive(null)} className="text-ink/90 hover:text-brand">
                          {l.label}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}
      </nav>
      <Modals />
    </>
  );
}

function HeaderAction({ href, label, icon, badge }: { href: string; label: string; icon: React.ReactNode; badge: number }) {
  return (
    <Link href={href} className="relative flex w-[56px] flex-col items-center gap-1 text-sm text-muted transition-colors hover:text-brand md:w-[84px]">
      <span className="relative">
        {icon}
        {badge > 0 && (
          <span className="absolute -top-1.5 -right-3 flex h-4 min-w-4 items-center justify-center rounded-full bg-brand px-1 text-[10px] font-bold text-white">
            {badge}
          </span>
        )}
      </span>
      <span className="hidden md:inline">{label}</span>
    </Link>
  );
}

function Modal({ children, onClose, title }: { children: React.ReactNode; onClose: () => void; title: string }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-[90] flex items-start justify-center bg-wine/40 p-4 pt-[8vh] backdrop-blur-[2px]" onMouseDown={onClose}>
      <div className="fade-up w-full max-w-[460px] rounded-3xl bg-white p-6 shadow-2xl md:p-8" onMouseDown={(e) => e.stopPropagation()}>
        <div className="mb-5 flex items-start justify-between gap-4">
          <h3 className="text-2xl font-bold">{title}</h3>
          <button onClick={onClose} aria-label="Закрыть" className="rounded-full bg-[#f6f3f4] p-2 hover:bg-brand-tint">
            <CloseIcon className="h-4 w-4" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Modals() {
  const { modal, closeModal, city, setCity, login } = useStore();
  const router = useRouter();
  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [q, setQ] = useState("");
  const [err, setErr] = useState("");

  if (modal === "city")
    return (
      <Modal title="Выберите город доставки" onClose={closeModal}>
        <p className="mb-3 text-sm text-muted">Или выберите из популярных</p>
        <div className="grid grid-cols-2 gap-2">
          {CITIES.map((c) => (
            <button
              key={c}
              onClick={() => setCity(c)}
              className={`rounded-xl px-4 py-3 text-left text-sm transition-colors ${c === city ? "bg-brand text-white" : "bg-[#f6f3f4] hover:bg-brand-tint"}`}
            >
              {c}
            </button>
          ))}
        </div>
      </Modal>
    );

  if (modal === "login")
    return (
      <Modal title="Войти" onClose={closeModal}>
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            if (phone.replace(/\D/g, "").length < 10) return setErr("Введите номер телефона полностью");
            login({ name: name.trim(), phone });
          }}
        >
          <input className="input" placeholder="Ваше имя" value={name} onChange={(e) => setName(e.target.value)} />
          <input className={`input ${err ? "error" : ""}`} placeholder="+7 (___) ___-__-__" inputMode="tel" value={phone} onChange={(e) => { setPhone(e.target.value); setErr(""); }} />
          {err && <p className="text-sm text-[#e5484d]">{err}</p>}
          <button className="btn-brand h-[52px] w-full text-base">Войти</button>
          <p className="text-xs text-muted">Войдите, чтобы копить бонусы — 10% от каждого заказа возвращаем баллами.</p>
        </form>
      </Modal>
    );

  if (modal === "search")
    return (
      <Modal title="Поиск по сайту" onClose={closeModal}>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!q.trim()) return;
            closeModal();
            router.push(`/search?q=${encodeURIComponent(q.trim())}`);
          }}
          className="flex gap-2"
        >
          <input autoFocus className="input" placeholder="Например: пионы, розы, Фламинго" value={q} onChange={(e) => setQ(e.target.value)} />
          <button className="btn-brand h-[52px] px-5">Найти</button>
        </form>
      </Modal>
    );
  return null;
}
