import type { OrderRow } from "@/db/schema";
import { DELIVERY_OPTIONS, DISTANCES, PAYMENT_METHODS, formatPrice } from "@/lib/pricing";

export const STATUS_LABELS: Record<string, string> = {
  new: "Принят, ожидает оплаты при получении",
  paid: "Оплачен, собираем букет",
};

export function OrderSummary({ o }: { o: OrderRow }) {
  const date = new Date(o.deliveryDate + "T12:00:00").toLocaleDateString("ru-RU", { day: "numeric", month: "long" });
  const rows: [string, string][] = [
    ["Статус", STATUS_LABELS[o.status] ?? o.status],
    ["Получатель", `${o.recipientName}, ${o.recipientPhone}`],
    ["Адрес", `${o.city}, ${o.street}, д. ${o.house}${o.flat ? `, кв. ${o.flat}` : ""}`],
    ["Доставка", `${date}, ${o.deliveryTime}`],
    ["Условия", `${DISTANCES.find((d) => d.id === o.distance)?.name ?? ""}; ${DELIVERY_OPTIONS.find((d) => d.id === o.deliveryOption)?.name ?? ""}`],
    ["Оплата", PAYMENT_METHODS.find((m) => m.id === o.paymentMethod)?.name ?? o.paymentMethod],
  ];
  if (o.cardText) rows.push(["Открытка", o.cardText]);
  if (o.comment) rows.push(["Комментарий", o.comment]);
  return (
    <div className="rounded-3xl border border-line bg-white p-6">
      <dl className="grid gap-x-6 gap-y-3 text-sm md:grid-cols-[140px_1fr]">
        {rows.map(([k, v]) => (
          <div key={k} className="contents">
            <dt className="text-muted">{k}</dt>
            <dd className="font-medium">{v}</dd>
          </div>
        ))}
      </dl>
      <ul className="mt-6 divide-y divide-line border-t border-line">
        {o.items.map((it, i) => (
          <li key={i} className="flex items-center gap-4 py-4">
            <div className="h-16 w-14 shrink-0 overflow-hidden rounded-lg bg-[#f6f3f4]">
              {it.image ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={it.image} alt="" className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full items-center justify-center bg-brand-soft text-2xl">🎁</div>
              )}
            </div>
            <div className="flex-1 text-sm">
              <div className="font-semibold">{it.name}</div>
              <div className="text-xs text-muted">{it.optionsLabel}</div>
              <div className="text-xs text-muted">{it.qty} × {formatPrice(it.price)}</div>
            </div>
            <b>{formatPrice(it.qty * it.price)}</b>
          </li>
        ))}
      </ul>
      <dl className="mt-2 space-y-1.5 border-t border-line pt-4 text-sm">
        <div className="flex justify-between"><dt className="text-muted">Товары</dt><dd>{formatPrice(o.subtotal)}</dd></div>
        {o.discount > 0 && <div className="flex justify-between text-green-600"><dt>Скидка ({o.promoCode})</dt><dd>− {formatPrice(o.discount)}</dd></div>}
        <div className="flex justify-between"><dt className="text-muted">Доставка</dt><dd>{o.deliveryPrice ? formatPrice(o.deliveryPrice) : "Бесплатно"}</dd></div>
        <div className="flex justify-between pt-2 text-xl font-bold"><dt>Итого</dt><dd>{formatPrice(o.total)}</dd></div>
        <div className="flex justify-between text-muted"><dt>Вернем баллами</dt><dd className="font-semibold text-[#e5a100]">{formatPrice(o.bonuses)}</dd></div>
      </dl>
    </div>
  );
}
