import Link from "next/link";
import { Logo } from "./Logo";

const COLS = [
  {
    title: "О компании",
    links: [
      ["О нас", "/o-kompanii"],
      ["Гарантии", "/o-kompanii"],
      ["Отзывы", "/reviews"],
      ["Вакансии", "/o-kompanii"],
      ["Сертификаты", "/o-kompanii"],
      ["Блог", "/blog"],
      ["Контакты", "/o-kompanii"],
    ],
  },
  {
    title: "Клиентам",
    links: [
      ["Каталог", "/catalog/all-2"],
      ["Акции и бонусы", "/1-1-3"],
      ["Способы оплаты", "/sposoby-oplaty"],
      ["Доставка", "/dostavka"],
      ["Вопросы – ответы", "/dostavka"],
      ["Фотографии клиентов", "/reviews"],
      ["Корпоративным клиентам", "/o-kompanii"],
    ],
  },
  {
    title: "Полезное",
    links: [
      ["Политика возврата", "/o-kompanii"],
      ["Публичная оферта", "/sposoby-oplaty"],
      ["Согласие на рекламу", "/o-kompanii"],
      ["Согласие на обработку персональных данных", "/o-kompanii"],
      ["Правила работы в праздники", "/dostavka"],
      ["E-mail подписка", "/o-kompanii"],
      ["Узнать статус заказа", "/order-status"],
    ],
  },
  {
    title: "Каталог",
    links: [
      ["Букеты из роз", "/catalog/bukety-roz"],
      ["Цветы в коробке", "/catalog/cvetochnye_korobki"],
      ["Цветы в корзине", "/catalog/kompozicii"],
      ["Подарки", "/catalog/podarki"],
      ["Хиты продаж", "/catalog/bestsellers"],
      ["Распродажа", "/catalog/novogodnyaya-rasprodazha"],
    ],
  },
];

export function Footer() {
  return (
    <footer className="mt-20 bg-[#faf6f7]">
      <div className="wrap py-12">
        <div className="flex flex-col gap-10 lg:flex-row lg:justify-between">
          <div className="max-w-[300px] space-y-4">
            <Logo />
            <p className="text-sm text-muted">Мы работаем 24 часа и 7 дней в неделю. Даже без перерыва!</p>
            <a href="tel:88006004360" className="block text-2xl font-bold">
              8 800 600-43-60
            </a>
            <a href="mailto:info@buket-v-otvet.ru" className="block text-sm text-brand hover:underline">
              info@buket-v-otvet.ru
            </a>
          </div>
          <div className="grid flex-1 grid-cols-2 gap-8 lg:grid-cols-4 lg:pl-12">
            {COLS.map((c) => (
              <div key={c.title}>
                <div className="mb-3 text-base font-bold text-wine">{c.title}</div>
                <ul className="space-y-2 text-sm text-ink/80">
                  {c.links.map(([label, href]) => (
                    <li key={label}>
                      <Link href={href} className="hover:text-brand">
                        {label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
        <div className="mt-10 flex flex-col gap-2 border-t border-line pt-6 text-sm text-muted md:flex-row md:justify-between">
          <span>© 2026 Букет в ответ — доставка цветов и подарков в Москве</span>
          <span>Москва, Варшавское ш., 26</span>
          <Link href="/o-kompanii" className="hover:text-brand">
            Политика конфиденциальности
          </Link>
        </div>
      </div>
    </footer>
  );
}
