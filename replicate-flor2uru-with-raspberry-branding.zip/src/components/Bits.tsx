import Link from "next/link";
import { StarIcon } from "./Icons";
import { FAQ } from "@/lib/catalog";

export function Breadcrumbs({ items }: { items: { label: string; href?: string }[] }) {
  return (
    <nav className="flex flex-wrap items-center gap-2 py-5 text-xs text-muted">
      {items.map((it, i) => (
        <span key={i} className="flex items-center gap-2">
          {it.href ? (
            <Link href={it.href} className="hover:text-brand">
              {it.label}
            </Link>
          ) : (
            <span className="font-medium text-ink">{it.label}</span>
          )}
          {i < items.length - 1 && <span className="text-[8px] text-brand/60">▶</span>}
        </span>
      ))}
    </nav>
  );
}

export function YandexBadge() {
  return (
    <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#fc3f1d] text-lg font-bold text-white">Я</span>
  );
}

export function Stars({ className = "h-6 w-6" }: { className?: string }) {
  return (
    <span className="flex text-[#ffb400]">
      {[0, 1, 2, 3, 4].map((i) => (
        <StarIcon key={i} className={className} />
      ))}
    </span>
  );
}

export function Faq() {
  return (
    <section className="mt-14">
      <h2 className="mb-6 text-3xl font-bold">Ответы на вопросы</h2>
      <div className="divide-y divide-line rounded-2xl bg-[#faf6f7]">
        {FAQ.map((f) => (
          <details key={f.q} className="group px-5 py-4">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-medium">
              {f.q}
              <span className="text-2xl leading-none text-brand transition-transform group-open:rotate-45">+</span>
            </summary>
            <p className="mt-3 text-sm leading-relaxed text-ink/75">{f.a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}

export function Benefits() {
  return (
    <div className="grid gap-4 rounded-2xl bg-[#faf6f7] p-5 text-center md:grid-cols-3 md:text-left">
      <div className="font-medium">🚚 Бесплатная доставка от 3-х часов</div>
      <div className="font-medium">💬 Круглосуточная поддержка</div>
      <div className="font-medium">🌷 Качество цветов гарантировано — или мы заменим букет</div>
    </div>
  );
}
