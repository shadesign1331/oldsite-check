"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

export function CookiePopup() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    if (!localStorage.getItem("bvo_cookie")) setShow(true);
  }, []);
  if (!show) return null;
  return (
    <div className="fade-up fixed bottom-5 left-5 z-[80] hidden w-[320px] rounded-2xl bg-white p-3 text-xs shadow-[0_8px_30px_rgba(60,10,30,0.18)] md:block">
      <p className="mb-3">Для улучшения работы сайта мы используем файлы cookies.</p>
      <p className="mb-3">
        Продолжая его использование, вы соглашаетесь с нашей{" "}
        <Link href="/o-kompanii" className="text-brand">
          Политикой конфиденциальности и использованием файлов cookie
        </Link>
      </p>
      <button
        onClick={() => {
          localStorage.setItem("bvo_cookie", "1");
          setShow(false);
        }}
        className="btn-brand h-8 w-full text-xs"
      >
        Хорошо
      </button>
    </div>
  );
}
