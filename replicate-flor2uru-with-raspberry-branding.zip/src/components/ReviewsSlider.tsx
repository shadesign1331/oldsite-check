"use client";

import { useRef } from "react";
import { ArrowIcon, StarIcon } from "./Icons";

export type ReviewItem = { name: string; text: string; img: string };

export function ReviewsSlider({ items, title = "Отзывы наших клиентов" }: { items: ReviewItem[]; title?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: number) => ref.current?.scrollBy({ left: dir * 300, behavior: "smooth" });
  return (
    <section className="rounded-[28px] bg-brand-soft p-5 md:p-6">
      <div className="mb-6 flex items-center justify-between">
        <h2 className="text-3xl font-bold">{title}</h2>
        <div className="flex gap-3">
          <button onClick={() => scroll(-1)} aria-label="Назад" className="flex h-10 w-10 items-center justify-center rounded-full bg-white hover:text-brand">
            <ArrowIcon dir="left" className="h-5 w-5" />
          </button>
          <button onClick={() => scroll(1)} aria-label="Вперёд" className="flex h-10 w-10 items-center justify-center rounded-full bg-white hover:text-brand">
            <ArrowIcon className="h-5 w-5" />
          </button>
        </div>
      </div>
      <div ref={ref} className="no-scrollbar flex gap-4 overflow-x-auto scroll-smooth">
        {items.map((r) => (
          <article key={r.name} className="w-[279px] shrink-0 overflow-hidden rounded-2xl bg-white">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={`/img/${r.img}.jpg`} alt={r.name} loading="lazy" className="h-[346px] w-full object-cover" />
            <div className="p-3">
              <div className="mb-2 flex items-center justify-between gap-2">
                <span className="font-medium">{r.name}</span>
                <span className="flex text-brand">
                  {[0, 1, 2, 3, 4].map((i) => (
                    <StarIcon key={i} className="h-3 w-3" />
                  ))}
                </span>
              </div>
              <p className="line-clamp-4 text-[13px] leading-snug text-ink/80">{r.text}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
