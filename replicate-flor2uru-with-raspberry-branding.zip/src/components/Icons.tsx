type P = { className?: string };
const base = { fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, viewBox: "0 0 24 24" };

export const HeartIcon = ({ className = "h-6 w-6", filled = false }: P & { filled?: boolean }) => (
  <svg {...base} className={className} fill={filled ? "currentColor" : "none"}>
    <path d="M12 21s-8-5.2-8-11a4.6 4.6 0 0 1 8-3 4.6 4.6 0 0 1 8 3c0 5.8-8 11-8 11Z" />
  </svg>
);
export const CartIcon = ({ className = "h-6 w-6" }: P) => (
  <svg {...base} className={className}>
    <path d="M3 4h2.5l2.2 11h10.2L20 7.5H6.2" />
    <circle cx="9" cy="19.5" r="1.4" />
    <circle cx="17" cy="19.5" r="1.4" />
  </svg>
);
export const UserIcon = ({ className = "h-6 w-6" }: P) => (
  <svg {...base} className={className}>
    <circle cx="12" cy="8" r="4" />
    <path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7" />
  </svg>
);
export const ClockIcon = ({ className = "h-6 w-6" }: P) => (
  <svg {...base} className={className}>
    <path d="M20 12a8 8 0 1 1-2.4-5.7" />
    <path d="M12 7v5l3 2" />
    <path d="M20 4v4h-4" />
  </svg>
);
export const SearchIcon = ({ className = "h-5 w-5" }: P) => (
  <svg {...base} className={className}>
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </svg>
);
export const ChevronDown = ({ className = "h-4 w-4" }: P) => (
  <svg {...base} className={className}>
    <path d="m6 9 6 6 6-6" />
  </svg>
);
export const CloseIcon = ({ className = "h-5 w-5" }: P) => (
  <svg {...base} className={className}>
    <path d="M6 6l12 12M18 6 6 18" />
  </svg>
);
export const ArrowIcon = ({ className = "h-5 w-5", dir = "right" }: P & { dir?: "left" | "right" }) => (
  <svg {...base} className={className} style={dir === "left" ? { transform: "rotate(180deg)" } : undefined}>
    <path d="M5 12h14M13 6l6 6-6 6" />
  </svg>
);
export const PinIcon = ({ className = "h-4 w-4" }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor">
    <path d="M21 3 3 10.5l7 2.5 2.5 7L21 3Z" />
  </svg>
);
export const TrashIcon = ({ className = "h-5 w-5" }: P) => (
  <svg {...base} className={className}>
    <path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6" />
  </svg>
);
export const PlusIcon = ({ className = "h-5 w-5" }: P) => (
  <svg {...base} className={className}>
    <path d="M12 5v14M5 12h14" />
  </svg>
);
export const MinusIcon = ({ className = "h-5 w-5" }: P) => (
  <svg {...base} className={className}>
    <path d="M5 12h14" />
  </svg>
);
export const StarIcon = ({ className = "h-5 w-5" }: P) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor">
    <path d="m12 2 3 6.6 7.2.8-5.4 4.8 1.5 7.1L12 17.7 5.7 21.3l1.5-7.1L1.8 9.4 9 8.6 12 2Z" />
  </svg>
);
export const CameraIcon = ({ className = "h-6 w-6" }: P) => (
  <svg {...base} className={className}>
    <path d="M4 8h3l1.5-2h7L17 8h3v11H4V8Z" />
    <circle cx="12" cy="13" r="3.2" />
  </svg>
);
export const PercentIcon = ({ className = "h-5 w-5" }: P) => (
  <svg {...base} className={className}>
    <path d="M19 5 5 19" />
    <circle cx="7" cy="7" r="2.5" />
    <circle cx="17" cy="17" r="2.5" />
  </svg>
);

export function NavIcon({ name, className = "h-[18px] w-[18px]" }: { name: string; className?: string }) {
  switch (name) {
    case "flowers":
      return (
        <svg viewBox="0 0 24 24" className={className} fill="currentColor">
          <rect x="3" y="3" width="8" height="8" rx="2" />
          <rect x="13" y="3" width="8" height="8" rx="2" />
          <rect x="3" y="13" width="8" height="8" rx="2" />
          <rect x="13" y="13" width="8" height="8" rx="2" />
        </svg>
      );
    case "occasion":
      return (
        <svg {...base} className={className}>
          <rect x="3.5" y="5" width="17" height="15" rx="2.5" />
          <path d="M3.5 10h17M8 3v4M16 3v4" />
        </svg>
      );
    case "roses":
      return (
        <svg {...base} className={className}>
          <circle cx="12" cy="9" r="5" />
          <path d="M9.5 8.5c1-1.2 3.5-1.2 4.5 0M12 14v7M12 17l-3-1.5M12 18.5l3-1.5" />
        </svg>
      );
    case "gifts":
      return (
        <svg {...base} className={className}>
          <rect x="3.5" y="9" width="17" height="11" rx="2" />
          <path d="M12 9v11M3.5 13h17M12 9c-3 0-5-4-2-4s2 4 2 4Zm0 0c3 0 5-4 2-4s-2 4-2 4Z" />
        </svg>
      );
    case "boxes":
      return (
        <svg {...base} className={className}>
          <path d="M4 10h16l-1.3 10H5.3L4 10ZM6 10 8 4h8l2 6" />
        </svg>
      );
    case "baskets":
      return (
        <svg {...base} className={className}>
          <path d="M4 11h16l-2 9H6l-2-9ZM8 11l3-6M16 11l-3-6M9 15v2M15 15v2M12 15v2" />
        </svg>
      );
    default:
      return <PercentIcon className={className} />;
  }
}
