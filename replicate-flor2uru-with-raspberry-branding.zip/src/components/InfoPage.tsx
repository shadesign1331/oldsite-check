import type { ReactNode } from "react";
import { Breadcrumbs } from "./Bits";

export function InfoPage({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="wrap max-w-[900px] pb-6">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: title }]} />
      <h1 className="mb-6 text-[34px] leading-tight font-bold">{title}</h1>
      <div className="prose-site">{children}</div>
    </div>
  );
}
