"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import type { Product } from "@/lib/catalog";
import { buildCartItem, defaultSelection } from "@/lib/cartItem";
import { PACKAGING, ROSE_COLORS, ROSE_COUNTS, ROSE_HEIGHTS, SIZES, calcPrice, formatPrice, type Selection } from "@/lib/pricing";
import { useStore } from "./StoreProvider";
import { FavButton } from "./ProductCard";
import { ArrowIcon, CameraIcon, MinusIcon, PlusIcon } from "./Icons";
import { Stars, YandexBadge } from "./Bits";

function Step({ n, children }: { n: number; children: React.ReactNode }) {
  return (
    <div className="mb-3 flex items-center gap-2 text-[15px] font-semibold">
      <span className="flex h-5 w-5 items-center justify-center rounded-full bg-brand-soft text-xs text-brand">{n}</span>
      {children}
    </div>
  );
}

export function ProductView({ p, dateLabel }: { p: Product; dateLabel: string }) {
  const { add } = useStore();
  const [sel, setSel] = useState<Selection>(() => defaultSelection(p));
  const [idx, setIdx] = useState(0);
  const [added, setAdded] = useState(false);
  const price = useMemo(() => calcPrice(p, sel), [p, sel]);
  const set = (patch: Partial<Selection>) => {
    setSel((s) => ({ ...s, ...patch }));
    setAdded(false);
  };
  const countIdx = Math.max(0, ROSE_COUNTS.indexOf(sel.count ?? p.roseCount ?? 21));
  const colorName = ROSE_COLORS.find((c) => c.id === sel.color)?.name;
  let n = 0;

  return (
    <div className="grid gap-8 lg:grid-cols-[528px_1fr] lg:gap-12">
      {/* Галерея */}
      <div>
        <div className="relative flex aspect-[4/4.4] items-center justify-center overflow-hidden rounded-3xl bg-[#f6f3f4]">
          {p.images.length ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={p.images[idx]} alt={p.name} className="h-full w-full object-cover" />
          ) : (
            <div className="text-[160px]">{p.emoji}</div>
          )}
          <FavButton slug={p.slug} className="absolute top-4 right-4 !h-10 !w-10" />
          <div className="absolute inset-x-4 bottom-4 flex items-center justify-center gap-2 rounded-xl bg-white/90 py-3 text-[15px] font-medium shadow backdrop-blur">
            <CameraIcon className="h-5 w-5 text-brand" />
            Пришлем фото букета перед доставкой
          </div>
        </div>
        <div className="mt-4 flex items-center gap-3 text-sm">
          <YandexBadge />
          <span className="text-xs">9132 отзыва</span>
          <span className="text-muted">Наш рейтинг</span>
          <b>4.7</b>
          <Stars className="h-5 w-5" />
        </div>
        {p.images.length > 1 && (
          <div className="mt-4 flex gap-3 overflow-x-auto no-scrollbar">
            {p.images.map((src, i) => (
              <button
                key={src}
                onClick={() => setIdx(i)}
                className={`h-16 w-16 shrink-0 overflow-hidden rounded-xl border-2 ${i === idx ? "border-brand" : "border-line"}`}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={src} alt="" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Опции */}
      <div>
        <h1 className="text-[28px] leading-tight font-bold">{p.name} в Москве</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">{p.description}</p>

        <div className="mt-6">
          {p.kind === "roses" && (
            <>
              <Step n={++n}>
                Выберите цвет роз: <span className="font-normal text-muted">{colorName}</span>
              </Step>
              <div className="mb-6 flex flex-wrap gap-3">
                {ROSE_COLORS.map((c) => (
                  <button
                    key={c.id}
                    title={c.name}
                    aria-label={c.name}
                    onClick={() => set({ color: c.id })}
                    className={`flex h-[60px] w-[60px] items-center justify-center rounded-xl border-2 bg-white transition-colors ${sel.color === c.id ? "border-brand" : "border-line hover:border-brand/50"}`}
                  >
                    <span className="h-9 w-9 rounded-full ring-1 ring-black/10" style={{ background: c.hex }} />
                  </button>
                ))}
              </div>

              <Step n={++n}>Выберите высоту роз:</Step>
              <div className="mb-6 flex flex-wrap gap-2">
                {ROSE_HEIGHTS.map((h) => (
                  <button
                    key={h}
                    onClick={() => set({ height: h })}
                    className={`h-9 rounded-xl border-2 px-4 text-sm ${sel.height === h ? "border-brand text-brand" : "border-line hover:border-brand/50"}`}
                  >
                    {h} см
                  </button>
                ))}
              </div>

              <Step n={++n}>Выберите количество роз, шт:</Step>
              <div className="mb-6 flex items-center gap-2">
                <button
                  aria-label="Меньше"
                  disabled={countIdx === 0}
                  onClick={() => set({ count: ROSE_COUNTS[countIdx - 1] })}
                  className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#f1ecee] hover:bg-brand-tint disabled:opacity-40"
                >
                  <MinusIcon />
                </button>
                <div className="flex h-9 w-20 items-center justify-center rounded-lg border border-line font-medium">{sel.count}</div>
                <button
                  aria-label="Больше"
                  disabled={countIdx === ROSE_COUNTS.length - 1}
                  onClick={() => set({ count: ROSE_COUNTS[countIdx + 1] })}
                  className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#f1ecee] hover:bg-brand-tint disabled:opacity-40"
                >
                  <PlusIcon />
                </button>
              </div>
            </>
          )}

          {(p.kind === "bouquet" || p.kind === "box" || p.kind === "basket") && (
            <>
              <Step n={++n}>Выберите размер:</Step>
              <div className="mb-6 flex flex-wrap gap-2">
                {SIZES.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => set({ size: s.id })}
                    className={`h-10 rounded-xl border-2 px-4 text-sm ${sel.size === s.id ? "border-brand text-brand" : "border-line hover:border-brand/50"}`}
                  >
                    {s.name}
                    {s.mult > 1 && <span className="ml-1 text-xs text-muted">+{Math.round((s.mult - 1) * 100)}%</span>}
                  </button>
                ))}
              </div>
            </>
          )}

          {p.kind !== "gift" && (
            <>
              <Step n={++n}>Выберите упаковку:</Step>
              <div className="mb-6 flex gap-3">
                {PACKAGING.map((pk) => (
                  <button key={pk.id} onClick={() => set({ packaging: pk.id })} className="flex w-[64px] flex-col items-center gap-1 text-center">
                    <span
                      className={`flex h-[60px] w-[60px] items-center justify-center rounded-xl border-2 text-2xl ${sel.packaging === pk.id ? "border-brand" : "border-line"}`}
                    >
                      {pk.id === "ribbon" ? "🎀" : "📜"}
                    </span>
                    <span className="text-[11px] leading-tight text-muted">
                      {pk.name}
                      {pk.price > 0 && <br />}
                      {pk.price > 0 && `+ ${formatPrice(pk.price)}`}
                      {pk.price === 0 && <br />}
                      {pk.price === 0 && "0 ₽"}
                    </span>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        <div className="flex items-center justify-between gap-6 border-t border-line pt-5">
          <div className="leading-tight">
            {p.oldPrice && <div className="text-sm text-muted line-through decoration-brand">{formatPrice(p.oldPrice)}</div>}
            <div className="text-[34px] font-bold">{formatPrice(price)}</div>
          </div>
          {added ? (
            <Link href="/personal/basket" className="btn-brand flex h-[62px] flex-1 items-center justify-center gap-2 text-lg !bg-wine hover:!bg-ink">
              Перейти в корзину <ArrowIcon />
            </Link>
          ) : (
            <button
              onClick={() => {
                add(buildCartItem(p, sel));
                setAdded(true);
              }}
              className="btn-brand h-[62px] flex-1 text-lg"
            >
              Купить
            </button>
          )}
        </div>

        <div className="mt-6 rounded-2xl bg-brand-soft p-5">
          <div className="mb-3 text-base font-semibold">Товар доступен к заказу на {dateLabel} с параметрами:</div>
          <dl className="grid grid-cols-[110px_1fr] gap-y-2 text-xs">
            {p.kind === "roses" ? (
              <>
                <dt className="text-muted">Цвет</dt>
                <dd>Красные, нежный микс, яркий микс, белые, кремовые, розовые, малиновые</dd>
                <dt className="text-muted">Количество</dt>
                <dd>11, 15, 21, 25, 35, 41, 51, 71 и 101 роза</dd>
                <dt className="text-muted">Высота роз</dt>
                <dd>35, 40, 50, 60 и 70 см</dd>
              </>
            ) : (
              <>
                <dt className="text-muted">Состав</dt>
                <dd>{p.flowers.length ? p.flowers.join(", ") : "—"}</dd>
                <dt className="text-muted">Размер</dt>
                <dd>Стандарт, большой, премиум</dd>
              </>
            )}
          </dl>
          <Link href="/catalog/mothers-day" className="mt-4 inline-block rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-brand hover:bg-brand-tint">
            Смотреть все букеты ко Дню матери
          </Link>
        </div>
      </div>
    </div>
  );
}
