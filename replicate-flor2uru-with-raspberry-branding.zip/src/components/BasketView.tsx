"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useStore } from "./StoreProvider";
import { formatPrice } from "@/lib/pricing";
import { formatPhone, isPhoneValid } from "@/lib/phone";
import { HeartIcon, MinusIcon, PlusIcon, TrashIcon } from "./Icons";

export function BasketView() {
  const { cart, ready, total, setQty, remove, favs, toggleFav, user } = useStore();
  const router = useRouter();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [messenger, setMessenger] = useState(false);
  const [errors, setErrors] = useState<{ name?: boolean; phone?: boolean }>({});

  useEffect(() => {
    try {
      const d = JSON.parse(localStorage.getItem("bvo_draft") || "null");
      if (d) {
        setName(d.name ?? "");
        setPhone(d.phone ?? "");
        setMessenger(!!d.messenger);
      }
    } catch {}
  }, []);
  useEffect(() => {
    if (user) {
      setName((n) => n || user.name);
      setPhone((p) => p || user.phone);
    }
  }, [user]);

  if (!ready) return <div className="h-64" />;

  if (!cart.length)
    return (
      <div className="flex flex-col items-center py-20 text-center">
        <div className="mb-4 text-7xl">🌷</div>
        <p className="mb-6 text-lg text-muted">Ваша корзина пуста. Вы можете выбрать товары в каталоге.</p>
        <Link href="/catalog/all-2" className="btn-brand flex h-12 items-center px-8">
          Перейти в каталог
        </Link>
      </div>
    );

  const submit = () => {
    const e = { name: name.trim().length < 2, phone: !isPhoneValid(phone) };
    setErrors(e);
    if (e.name || e.phone) return;
    localStorage.setItem("bvo_draft", JSON.stringify({ name: name.trim(), phone, messenger }));
    router.push("/personal/order");
  };

  const bonus = Math.round(total * 0.1);

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_368px] lg:gap-[92px]">
      <div>
        {cart.map((it) => (
          <div key={it.key} className="flex gap-4 border-b border-line py-5 first:pt-0">
            <Link href={`/product/${it.slug}`} className="block h-[120px] w-[100px] shrink-0 overflow-hidden rounded-xl bg-[#f6f3f4]">
              {it.image ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={it.image} alt={it.name} className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full items-center justify-center bg-brand-soft text-5xl">{it.emoji}</div>
              )}
            </Link>
            <div className="flex flex-1 flex-col">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <Link href={`/product/${it.slug}`} className="text-lg leading-tight font-semibold hover:text-brand">
                    {it.name}
                  </Link>
                  {it.optionsLabel && <div className="mt-2 text-sm text-muted">{it.optionsLabel}</div>}
                </div>
                <div className="flex gap-2">
                  <button
                    aria-label="В избранное"
                    onClick={() => toggleFav(it.slug)}
                    className={`flex h-9 w-9 items-center justify-center rounded-lg bg-[#f6f3f4] hover:text-brand ${favs.includes(it.slug) ? "text-brand" : "text-muted"}`}
                  >
                    <HeartIcon className="h-5 w-5" filled={favs.includes(it.slug)} />
                  </button>
                  <button aria-label="Убрать товар из корзины" onClick={() => remove(it.key)} className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#f6f3f4] text-muted hover:text-brand">
                    <TrashIcon className="h-5 w-5" />
                  </button>
                </div>
              </div>
              <div className="mt-auto flex items-center justify-between pt-3">
                <div className="flex items-center gap-1.5">
                  <button aria-label="Меньше" onClick={() => setQty(it.key, it.qty - 1)} className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#f1ecee] hover:bg-brand-tint">
                    <MinusIcon className="h-4 w-4" />
                  </button>
                  <div className="flex h-9 w-[88px] items-center justify-center rounded-lg bg-[#f6f3f4] font-medium">{it.qty}</div>
                  <button aria-label="Больше" onClick={() => setQty(it.key, it.qty + 1)} className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#f1ecee] hover:bg-brand-tint">
                    <PlusIcon className="h-4 w-4" />
                  </button>
                </div>
                <div className="text-[28px] font-bold">{formatPrice(it.price * it.qty)}</div>
              </div>
            </div>
          </div>
        ))}
        <div className="mt-5 inline-flex items-center gap-3 rounded-2xl bg-[#f6f3f4] px-5 py-4 text-sm text-muted">
          <span className="text-brand">%</span>
          Промокод и бонусы будут доступны
          <br />
          на следующем этапе оформления
        </div>
      </div>

      <aside>
        <div className="mb-3 flex items-center justify-center gap-2 text-sm font-semibold">🚚 Бесплатная доставка</div>
        <div className="rounded-3xl border border-line bg-white p-6">
          <h2 className="mb-4 text-2xl font-bold">Итого</h2>
          <div className="flex justify-between border-b border-line pb-4 text-sm">
            <span className="text-muted">{cart.reduce((s, i) => s + i.qty, 0)} товар(ов)</span>
            <b>{formatPrice(total)}</b>
          </div>
          <div className="mt-4 flex items-center justify-between">
            <span className="text-sm">Сумма</span>
            <span className="text-2xl font-bold">{formatPrice(total)}</span>
          </div>
          <div className="mt-1 flex justify-between text-sm text-muted">
            <span>Вернем баллами</span>
            <span className="font-semibold text-[#e5a100]">{formatPrice(bonus)}</span>
          </div>

          <h3 className="mt-6 mb-3 text-xl font-bold">Оформление заказа</h3>
          <div className="space-y-3">
            <input className={`input ${errors.name ? "error" : ""}`} placeholder="Ваше имя" value={name} onChange={(e) => setName(e.target.value)} />
            <input
              className={`input ${errors.phone ? "error" : ""}`}
              placeholder="+7(___)___-__-__"
              inputMode="tel"
              value={phone}
              onChange={(e) => setPhone(formatPhone(e.target.value))}
            />
            {(errors.name || errors.phone) && <p className="text-sm text-[#e5484d]">Укажите имя и телефон полностью</p>}
            <label className="flex cursor-pointer items-center gap-2 text-sm">
              <input type="checkbox" checked={messenger} onChange={(e) => setMessenger(e.target.checked)} className="h-5 w-5 accent-[#dc1458]" />
              Связь через мессенджер
            </label>
            <button onClick={submit} className="btn-brand h-[52px] w-full text-lg">
              Перейти к оформлению
            </button>
            <p className="text-[11px] leading-snug text-muted">
              Нажимая кнопку «Перейти к оформлению» вы соглашаетесь с <Link href="/sposoby-oplaty" className="text-brand">Офертой</Link> и даёте{" "}
              <Link href="/o-kompanii" className="text-brand">Согласие на обработку своих персональных данных</Link> в порядке и на условиях, предусмотренных Политикой обработки персональных данных
            </p>
          </div>
        </div>
      </aside>
    </div>
  );
}
