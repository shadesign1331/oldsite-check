"use client";

import Link from "next/link";
import type { Product } from "@/lib/catalog";
import { useStore } from "./StoreProvider";
import { ProductGrid } from "./ProductCard";

export function FavList({ all }: { all: Product[] }) {
  const { favs, ready } = useStore();
  if (!ready) return <div className="h-40" />;
  const items = all.filter((p) => favs.includes(p.slug));
  if (!items.length)
    return (
      <div className="py-16 text-center">
        <div className="mb-3 text-6xl">💗</div>
        <p className="mb-6 text-muted">В избранном пока пусто. Нажмите на сердечко у понравившегося букета.</p>
        <Link href="/catalog/all-2" className="btn-brand inline-flex h-12 items-center px-8">
          В каталог
        </Link>
      </div>
    );
  return <ProductGrid items={items} />;
}
