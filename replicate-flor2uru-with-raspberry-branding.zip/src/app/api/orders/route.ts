import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, type OrderItem } from "@/db/schema";
import { getProduct } from "@/lib/catalog";
import {
  DELIVERY_OPTIONS,
  DISTANCES,
  PAYMENT_METHODS,
  TIME_SLOTS,
  calcDelivery,
  calcDiscount,
  calcPrice,
  selectionLabel,
  type Selection,
} from "@/lib/pricing";

export const dynamic = "force-dynamic";

type Body = {
  customerName?: string;
  customerPhone?: string;
  recipientName?: string;
  recipientPhone?: string;
  city?: string;
  street?: string;
  house?: string;
  flat?: string;
  comment?: string;
  cardText?: string;
  deliveryDate?: string;
  deliveryTime?: string;
  distance?: string;
  deliveryOption?: string;
  paymentMethod?: string;
  promoCode?: string;
  items?: { slug: string; qty: number; options: Selection }[];
};

const str = (v: unknown, max = 500) => (typeof v === "string" ? v.trim().slice(0, max) : "");

export async function POST(req: Request) {
  let b: Body;
  try {
    b = (await req.json()) as Body;
  } catch {
    return NextResponse.json({ error: "Некорректный запрос" }, { status: 400 });
  }

  const customerName = str(b.customerName, 100);
  const customerPhone = str(b.customerPhone, 32);
  const recipientName = str(b.recipientName, 100) || customerName;
  const recipientPhone = str(b.recipientPhone, 32) || customerPhone;
  const street = str(b.street, 200);
  const house = str(b.house, 32);
  const deliveryDate = str(b.deliveryDate, 16);

  if (customerName.length < 2) return NextResponse.json({ error: "Укажите ваше имя" }, { status: 400 });
  if (customerPhone.replace(/\D/g, "").length < 11) return NextResponse.json({ error: "Укажите телефон" }, { status: 400 });
  if (!street || !house) return NextResponse.json({ error: "Укажите адрес доставки" }, { status: 400 });
  if (!/^\d{4}-\d{2}-\d{2}$/.test(deliveryDate)) return NextResponse.json({ error: "Выберите дату доставки" }, { status: 400 });

  const distance = DISTANCES.some((d) => d.id === b.distance) ? (b.distance as string) : "mkad";
  const slot = TIME_SLOTS.find((t) => t.id === b.deliveryTime);
  if (!slot) return NextResponse.json({ error: "Выберите время доставки" }, { status: 400 });
  const deliveryOption = DELIVERY_OPTIONS.some((d) => d.id === b.deliveryOption) ? (b.deliveryOption as string) : "standard";
  const paymentMethod = PAYMENT_METHODS.some((m) => m.id === b.paymentMethod) ? (b.paymentMethod as string) : "card";

  const items: OrderItem[] = [];
  for (const it of b.items ?? []) {
    const p = getProduct(it.slug);
    const qty = Math.max(1, Math.min(99, Math.floor(Number(it.qty) || 1)));
    if (!p) continue;
    const options = it.options ?? {};
    items.push({
      slug: p.slug,
      name: p.name,
      image: p.images[0] ?? null,
      qty,
      price: calcPrice(p, options),
      options: options as Record<string, string | number>,
      optionsLabel: selectionLabel(p, options),
    });
  }
  if (!items.length) return NextResponse.json({ error: "Корзина пуста" }, { status: 400 });

  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
  const promoCode = str(b.promoCode, 32).toUpperCase();
  const discount = calcDiscount(subtotal, promoCode);
  const deliveryPrice = calcDelivery(distance, slot.id, deliveryOption);
  const total = subtotal - discount + deliveryPrice;
  const bonuses = Math.round((subtotal - discount) * 0.1);

  let number = "";
  for (let i = 0; i < 5; i++) {
    number = String(Math.floor(1000000 + Math.random() * 8999999));
    try {
      await db.insert(orders).values({
        number,
        customerName,
        customerPhone,
        recipientName,
        recipientPhone,
        city: str(b.city, 100) || "Москва и МО",
        street,
        house,
        flat: str(b.flat, 32),
        comment: str(b.comment, 1000),
        cardText: str(b.cardText, 1000),
        deliveryDate,
        deliveryTime: slot.name,
        distance,
        deliveryOption,
        paymentMethod,
        promoCode: discount > 0 ? promoCode : "",
        items,
        subtotal,
        discount,
        deliveryPrice,
        total,
        bonuses,
        status: paymentMethod === "card" ? "paid" : "new",
      });
      return NextResponse.json({ number, total });
    } catch (e) {
      if (i === 4) {
        console.error(e);
        return NextResponse.json({ error: "Не удалось сохранить заказ, попробуйте ещё раз" }, { status: 500 });
      }
    }
  }
  return NextResponse.json({ error: "Ошибка" }, { status: 500 });
}
