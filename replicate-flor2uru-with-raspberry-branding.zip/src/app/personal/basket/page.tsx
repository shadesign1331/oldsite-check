import { Breadcrumbs } from "@/components/Bits";
import { BasketView } from "@/components/BasketView";

export const metadata = { title: "Корзина | Букет в ответ" };

export default function BasketPage() {
  return (
    <div className="wrap pb-6">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "Ваш заказ" }]} />
      <h1 className="mb-6 text-[26px] font-bold">Корзина</h1>
      <BasketView />
    </div>
  );
}
