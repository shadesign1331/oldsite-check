import { Breadcrumbs } from "@/components/Bits";
import { OrderForm } from "@/components/OrderForm";

export const metadata = { title: "Оформление заказа | Букет в ответ" };

export default function OrderPage() {
  return (
    <div className="wrap pb-6">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "Корзина", href: "/personal/basket" }, { label: "Оформление заказа" }]} />
      <h1 className="mb-6 text-[26px] font-bold">Оформление заказа</h1>
      <OrderForm />
    </div>
  );
}
