import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { PRODUCTS, getProduct } from "@/lib/catalog";
import { REVIEWS } from "@/lib/catalog";
import { Benefits, Breadcrumbs, Faq } from "@/components/Bits";
import { ProductView } from "@/components/ProductView";
import { ReviewsSlider } from "@/components/ReviewsSlider";
import { ProductGrid } from "@/components/ProductCard";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const p = getProduct(slug);
  return { title: p ? `${p.name} — купить с доставкой в Москве | Букет в ответ` : "Букет в ответ" };
}

export default async function ProductPage({ params }: Props) {
  const { slug } = await params;
  const p = getProduct(slug);
  if (!p) notFound();
  const d = new Date(Date.now() + 24 * 3600 * 1000);
  const dateLabel = `${String(d.getDate()).padStart(2, "0")}.${String(d.getMonth() + 1).padStart(2, "0")}`;
  const similar = PRODUCTS.filter((x) => x.kind === p.kind && x.slug !== p.slug).slice(0, 4);

  return (
    <div className="wrap pb-6">
      <Breadcrumbs
        items={[
          { label: "Главная", href: "/" },
          { label: "Цветы", href: "/catalog/all-2" },
          p.kind === "roses"
            ? { label: "Букеты из роз", href: "/catalog/bukety-roz" }
            : p.kind === "box"
              ? { label: "Цветы в коробке", href: "/catalog/cvetochnye_korobki" }
              : p.kind === "basket"
                ? { label: "Цветы в корзине", href: "/catalog/kompozicii" }
                : p.kind === "gift"
                  ? { label: "Подарки", href: "/catalog/podarki" }
                  : { label: "Авторские букеты", href: "/catalog/avtorskie-bukety" },
          { label: p.name },
        ]}
      />
      <ProductView p={p} dateLabel={dateLabel} />
      <div className="mt-12">
        <Benefits />
      </div>
      {similar.length > 0 && (
        <section className="mt-14">
          <h2 className="mb-6 text-3xl font-bold">Вам может понравиться</h2>
          <ProductGrid items={similar} />
        </section>
      )}
      <div className="mt-14">
        <ReviewsSlider items={REVIEWS} />
      </div>
      <Faq />
    </div>
  );
}
