import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Onest } from "next/font/google";
import "./globals.css";
import { StoreProvider } from "@/components/StoreProvider";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { CookiePopup } from "@/components/CookiePopup";

const onest = Onest({ subsets: ["latin", "cyrillic"], variable: "--font-onest", display: "swap" });

export const metadata: Metadata = {
  title: "Доставка цветов в Москве на дом, заказать букет цветов с доставкой — Букет в ответ",
  description: "Букет в ответ — доставка свежих цветов и подарков в Москве и по России. Цветы простоят 5 дней — или заменим букет. Фото букета перед доставкой.",
  icons: { icon: "/icon.svg" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" className={onest.variable}>
      <body>
        <StoreProvider>
          <Header />
          <main className="min-h-[60vh]">{children}</main>
          <Footer />
          <CookiePopup />
        </StoreProvider>
      </body>
    </html>
  );
}
