import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getCategory, getCategoryProducts, sortProducts, type Sort } from "@/lib/catalog";
import { MENU } from "@/lib/menu";
import { Breadcrumbs } from "@/components/Bits";
import { ProductGrid } from "@/components/ProductCard";
import { SortSelect } from "@/components/SortSelect";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }>; searchParams: Promise<{ sort?: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const c = getCategory(slug);
  return { title: c ? `${c.h1} | Букет в ответ` : "Букет в ответ" };
}

export default async function CatalogPage({ params, searchParams }: Props) {
  const { slug } = await params;
  const { sort = "popular" } = await searchParams;
  const cat = getCategory(slug);
  if (!cat) notFound();
  const items = sortProducts(getCategoryProducts(slug), sort as Sort);
  const parent = MENU.find((m) => m.columns.some((c) => c.links.some((l) => l.slug === slug)));
  const chips = (parent?.columns.find((c) => c.links.some((l) => l.slug === slug))?.links ?? []).slice(0, 14);

  return (
    <div className="wrap">
      <Breadcrumbs
        items={[
          { label: "Главная", href: "/" },
          { label: "Цветы", href: "/catalog/all-2" },
          ...(parent && parent.slug !== "all-2" ? [{ label: parent.label, href: `/catalog/${parent.slug}` }] : []),
          { label: cat.title },
        ]}
      />
      <h1 className="text-[34px] leading-tight font-bold">{cat.h1}</h1>
      <p className="mt-3 text-[15px] text-muted">{cat.description}</p>

      {chips.length > 1 && (
        <div className="no-scrollbar mt-6 flex gap-2 overflow-x-auto">
          {chips.map((c) => (
            <Link
              key={c.slug + c.label}
              href={`/catalog/${c.slug}`}
              className={`shrink-0 rounded-full px-4 py-2 text-sm transition-colors ${c.slug === slug ? "bg-brand text-white" : "bg-brand-soft hover:bg-brand-tint"}`}
            >
              {c.label}
            </Link>
          ))}
        </div>
      )}

      <div className="mt-6 mb-6 flex items-center justify-between">
        <SortSelect value={sort} />
        <span className="text-sm text-muted">{items.length} товаров</span>
      </div>
      {items.length ? <ProductGrid items={items} /> : <p className="py-20 text-center text-muted">В этой категории пока нет товаров.</p>}

      <div className="prose-site mt-16 max-w-3xl">
        <h2>{cat.title} в Москве</h2>
        <p>
          В «Букете в ответ» вы найдёте свежие цветы по честным ценам. Мы собираем каждый букет в день доставки, присылаем фото перед отправкой и гарантируем свежесть — цветы простоят 5 дней, или мы заменим букет.
        </p>
        <p>Доставка по Москве и МО работает круглосуточно: выберите удобный 3-х часовой интервал или закажите срочную доставку от 2 часов.</p>
      </div>
    </div>
  );
}
