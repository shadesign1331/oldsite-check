import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { OrderSummary } from "@/components/OrderSummary";
import { Breadcrumbs } from "@/components/Bits";
import { phoneDigits } from "@/lib/phone";

export const dynamic = "force-dynamic";
export const metadata = { title: "Узнать статус заказа | Букет в ответ" };

export default async function StatusPage({ searchParams }: { searchParams: Promise<{ number?: string; phone?: string }> }) {
  const { number = "", phone = "" } = await searchParams;
  const searched = number.trim().length > 0;
  let order = null;
  if (searched && /^\d{4,12}$/.test(number.trim())) {
    const [o] = await db.select().from(orders).where(and(eq(orders.number, number.trim()))).limit(1);
    // телефон опционален, но если указан — должен совпасть
    if (o && (!phone.trim() || phoneDigits(o.customerPhone) === phoneDigits(phone) || phoneDigits(o.recipientPhone) === phoneDigits(phone))) order = o;
  }
  return (
    <div className="wrap max-w-[820px] pb-6">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "Статус заказа" }]} />
      <h1 className="mb-6 text-[34px] font-bold">Узнать статус заказа</h1>
      <form className="mb-8 grid gap-3 md:grid-cols-[1fr_1fr_auto]">
        <input name="number" defaultValue={number} placeholder="Номер заказа" className="input" inputMode="numeric" />
        <input name="phone" defaultValue={phone} placeholder="Телефон (необязательно)" className="input" />
        <button className="btn-brand h-[52px] px-8">Найти</button>
      </form>
      {searched && !order && <div className="rounded-2xl bg-brand-soft p-6 text-center">Заказ не найден. Проверьте номер заказа и телефон.</div>}
      {order && (
        <>
          <h2 className="mb-4 text-2xl font-bold">Заказ №{order.number}</h2>
          <OrderSummary o={order} />
        </>
      )}
    </div>
  );
}
