import Link from "next/link";
import { Breadcrumbs } from "@/components/Bits";

export const metadata = { title: "Блог | Букет в ответ" };

const POSTS = [
  { t: "Как продлить жизнь букета: 7 советов флористов", d: "Подрезайте стебли под углом, меняйте воду каждые два дня и держите букет подальше от батарей и фруктов.", img: "peony-2" },
  { t: "Язык цветов: что означают розы разных цветов", d: "Красные розы — о страсти, белые — о чистоте, кремовые — о восхищении, малиновые — о благодарности.", img: "red-2" },
  { t: "Что подарить маме на День матери", d: "Нежные пионовидные розы, хризантемы и эустома в мягкой упаковке — выбор, который точно порадует.", img: "pink-6" },
  { t: "Сколько роз дарить: значение количества", d: "1 роза — внимание, 11 — искренность, 25 — признание, 51 — любовь, 101 — вечное чувство.", img: "pink-2" },
];

export default function Page() {
  return (
    <div className="wrap pb-6">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "Блог" }]} />
      <h1 className="mb-8 text-[34px] font-bold">Блог о цветах</h1>
      <div className="grid gap-5 md:grid-cols-2">
        {POSTS.map((p) => (
          <Link key={p.t} href="/catalog/all-2" className="group flex gap-4 overflow-hidden rounded-2xl bg-[#faf6f7] p-3 transition-shadow hover:shadow-lg">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={`/img/${p.img}.jpg`} alt="" loading="lazy" className="h-36 w-32 shrink-0 rounded-xl object-cover" />
            <div className="py-1">
              <div className="mb-2 text-lg leading-tight font-bold group-hover:text-brand">{p.t}</div>
              <p className="text-sm text-muted">{p.d}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
