import { InfoPage } from "@/components/InfoPage";
import { DISTANCES, TIME_SLOTS, DELIVERY_OPTIONS, formatPrice } from "@/lib/pricing";

export const metadata = { title: "Доставка цветов | Букет в ответ" };

export default function Page() {
  return (
    <InfoPage title="Доставка по Москве">
      <div className="not-prose mb-8 grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl bg-brand-soft p-5">
          <div className="mb-3 font-bold">1. Расстояние</div>
          {DISTANCES.map((d) => (
            <div key={d.id} className="flex justify-between gap-3 py-1 text-sm">
              <span>{d.name}</span>
              <b>{d.price ? formatPrice(d.price) : "0 ₽"}</b>
            </div>
          ))}
        </div>
        <div className="rounded-2xl bg-brand-soft p-5">
          <div className="mb-3 font-bold">2. Время доставки</div>
          {TIME_SLOTS.map((d) => (
            <div key={d.id} className="flex justify-between gap-3 py-1 text-sm">
              <span>{d.name}</span>
              <b>{d.price ? formatPrice(d.price) : "0 ₽"}</b>
            </div>
          ))}
        </div>
        <div className="rounded-2xl bg-brand-soft p-5">
          <div className="mb-3 font-bold">3. Опции</div>
          {DELIVERY_OPTIONS.map((d) => (
            <div key={d.id} className="flex justify-between gap-3 py-1 text-sm">
              <span>{d.name}</span>
              <b>{d.price ? "+ " + formatPrice(d.price) : "0 ₽"}</b>
            </div>
          ))}
        </div>
      </div>
      <p>Доставка цветов осуществляется по России! Вы выбираете любой 3-х часовой промежуток времени, в который мы доставим букет.</p>
      <p>Возможна срочная доставка по городу Москва и МО — до 2 часов. Срочная доставка цветов не осуществляется в праздники — Новый год, День Святого Валентина, 8 Марта, День Матери и предпраздничные дни.</p>
      <p>Если адрес доставки находится за пределами МКАД, то для таких заказов интервал времени доставки увеличивается на час.</p>
      <p>Мы работаем 24 часа и 7 дней в неделю. Даже без перерыва!</p>
    </InfoPage>
  );
}
