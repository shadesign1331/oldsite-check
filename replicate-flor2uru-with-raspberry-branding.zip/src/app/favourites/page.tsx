import { PRODUCTS } from "@/lib/catalog";
import { Breadcrumbs } from "@/components/Bits";
import { FavList } from "@/components/FavList";

export const metadata = { title: "Избранное | Букет в ответ" };

export default function FavouritesPage() {
  return (
    <div className="wrap">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "Избранное" }]} />
      <h1 className="mb-6 text-[34px] font-bold">Избранное</h1>
      <FavList all={PRODUCTS} />
    </div>
  );
}
