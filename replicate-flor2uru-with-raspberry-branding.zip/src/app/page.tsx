import Link from "next/link";
import { BY_SLUG, MAP_REVIEWS, REVIEWS, getCategoryProducts, sortProducts } from "@/lib/catalog";
import { ROSE_COLORS, formatPrice } from "@/lib/pricing";
import { Faq, Stars, YandexBadge } from "@/components/Bits";
import { ProductCard } from "@/components/ProductCard";
import { ReviewsSlider } from "@/components/ReviewsSlider";
import { ArrowIcon } from "@/components/Icons";

const ROSE_SLUGS = ["buket-iz-21-rozy", "buket-iz-35-roz", "buket-iz-51-rozy", "buket-iz-101-rozy"];

const PROMOS = [
  { title: "Доставка от 3-х часов", text: "Бесплатная доставка по России, 98% доставлено вовремя", emoji: "🚚" },
  { title: "Фото вашего букета", text: "Мы пришлем фото вашего букета перед доставкой", emoji: "📸" },
  { title: "Цветы простоят 5 дней", text: "Или мы заменим букет!", emoji: "🌷" },
];

export default function HomePage() {
  const mothers = sortProducts(getCategoryProducts("mothers-day"), "popular").slice(0, 7);
  const roses = ROSE_SLUGS.map((s) => BY_SLUG.get(s)!).filter(Boolean);

  return (
    <div className="wrap pt-5">
      {/* Баннер */}
      <Link
        href="/catalog/mothers-day"
        className="relative flex h-[148px] items-center overflow-hidden rounded-[28px] bg-gradient-to-r from-[#b50e47] via-brand to-[#ff5a8a] px-6 text-white md:h-[84px] md:rounded-[24px] md:px-[60px] md:[height:112px]"
      >
        <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1080 112" preserveAspectRatio="none" aria-hidden="true">
          <path d="M330 0 C 420 60, 520 -20, 640 70 S 760 120, 820 40" stroke="rgba(255,255,255,.35)" strokeWidth="26" fill="none" />
          <path d="M700 112 C 800 40, 900 100, 960 20" stroke="rgba(255,255,255,.22)" strokeWidth="20" fill="none" />
        </svg>
        <div className="relative z-10 flex-1">
          <div className="text-3xl font-bold md:text-[28px]">День матери</div>
          <div className="text-[15px] opacity-90">Букеты и подарки любимой маме</div>
        </div>
        <span className="relative z-10 hidden h-12 items-center rounded-full bg-white px-6 font-semibold text-brand transition-colors hover:bg-brand-tint md:flex">Смотреть каталог</span>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/img/pink-1.jpg" alt="" className="absolute -right-6 -bottom-8 hidden h-[120px] w-[120px] rounded-full object-cover md:block" />
      </Link>

      {/* Рейтинг */}
      <div className="flex flex-wrap items-center justify-center gap-4 py-6 md:gap-6">
        <span className="text-sm text-muted">Доставка цветов в Москве</span>
        <YandexBadge />
        <span className="hidden h-10 w-px bg-line md:block" />
        <span className="font-medium text-ink/80">Наш рейтинг</span>
        <span className="text-[52px] leading-none font-bold">4.7</span>
        <div>
          <Stars className="h-7 w-7" />
          <div className="text-[11px] text-muted">9132 отзыва • 4578 оценок</div>
        </div>
      </div>

      {/* Преимущества */}
      <div className="grid gap-4 md:grid-cols-3">
        {PROMOS.map((p) => (
          <div key={p.title} className="relative flex min-h-[120px] flex-col justify-between overflow-hidden rounded-2xl bg-brand-soft p-4 pr-24">
            <div className="text-[22px] leading-tight font-bold">{p.title}</div>
            <div className="mt-3 text-[15px] leading-tight text-muted">{p.text}</div>
            <span className="absolute right-3 bottom-2 text-6xl">{p.emoji}</span>
          </div>
        ))}
      </div>

      {/* Конструктор роз */}
      <section className="mt-7 rounded-[32px] bg-brand-soft p-5 md:p-8">
        <h2 className="mb-6 text-center text-xl leading-snug font-bold md:text-[22px]">
          Соберите свой букет роз.
          <br />
          Внутри вы можете указать длину, упаковку и цвет
        </h2>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
          {roses.map((p) => (
            <div key={p.slug} className="group flex flex-col overflow-hidden rounded-2xl bg-white p-2">
              <Link href={`/product/${p.slug}`} className="block aspect-[1/1.05] overflow-hidden rounded-xl bg-[#f6f3f4]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={p.images[0]} alt={p.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
              </Link>
              <div className="px-2 pt-3 text-[15px]">{p.name}</div>
              <div className="flex gap-1 px-2 py-2">
                {ROSE_COLORS.slice(0, 9).map((c) => (
                  <span key={c.id} className="h-5 w-5 rounded-full ring-1 ring-black/10" style={{ background: c.hex }} />
                ))}
              </div>
              <div className="mt-auto flex items-center justify-between px-2 pb-2">
                <span className="text-xl font-bold">{formatPrice(p.price)}</span>
                <Link href={`/product/${p.slug}`} className="btn-brand flex h-[34px] items-center px-5 text-sm">
                  Купить
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 1+1=3 */}
      <Link href="/1-1-3" className="relative mt-10 flex h-[90px] items-center overflow-hidden rounded-[24px] bg-brand text-white">
        <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 1080 90" preserveAspectRatio="none" aria-hidden="true">
          <path d="M452 90 C 500 0, 520 0, 540 0 L 1080 0" fill="rgba(255,255,255,.12)" />
          <path d="M1090 90 L1190 0 L1130 0 L1040 90Z" fill="rgba(0,0,0,.08)" />
        </svg>
        <span className="relative px-6 text-[44px] leading-none font-black md:px-12 md:text-[52px]">1+1=3</span>
        <span className="relative ml-auto pr-6 text-lg leading-tight font-bold md:mr-[200px] md:pr-0 md:text-[32px]">
          Сделайте 2 заказа —
          <br />3-й букет за 1 ₽
        </span>
      </Link>

      {/* Отзывы с фото */}
      <div className="mt-10">
        <ReviewsSlider items={REVIEWS} />
      </div>

      {/* Ко Дню матери */}
      <section className="mt-14">
        <div className="mb-6 flex items-end justify-between">
          <h2 className="text-3xl font-bold">Букеты ко Дню матери</h2>
          <Link href="/catalog/mothers-day" className="text-sm font-semibold text-brand hover:underline">
            Показать все
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-3 md:gap-5 lg:grid-cols-4">
          {mothers.map((p) => (
            <ProductCard key={p.slug} p={p} />
          ))}
          <Link href="/catalog/mothers-day" className="group flex flex-col justify-between rounded-2xl bg-brand-soft p-4">
            <div className="flex flex-1 flex-col items-center justify-center rounded-2xl rounded-br-[60px] bg-white py-8 text-center text-brand">
              <div className="text-6xl leading-none font-bold">
                <span className="align-top text-2xl">+</span>110
              </div>
              <div className="mt-1 text-2xl leading-tight font-bold">
                букетов
                <br />
                внутри
              </div>
            </div>
            <div className="mt-4 flex items-center justify-between font-semibold text-brand">
              <span className="text-sm leading-tight">
                Показать все
                <br />
                букеты ко
                <br />
                дню матери
              </span>
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-white transition-transform group-hover:translate-x-1">
                <ArrowIcon />
              </span>
            </div>
          </Link>
        </div>
      </section>

      {/* Отзывы Яндекс.Карт */}
      <section className="mt-14">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-3xl font-bold">Отзывы наших покупателей</h2>
          <div className="flex items-center gap-3 text-sm text-muted">
            <span className="font-semibold text-ink">Карты</span>
            На основе 4578 оценок
          </div>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {MAP_REVIEWS.map((r) => (
            <article key={r.name} className="flex flex-col rounded-2xl bg-[#faf6f7] p-5">
              <div className="font-semibold">{r.name}</div>
              <div className="mb-2 text-xs text-muted">{r.date}</div>
              <Stars className="mb-3 h-4 w-4" />
              <p className="text-sm leading-relaxed text-ink/80">{r.text}</p>
              <span className="mt-auto pt-4 text-xs text-muted">Отзывы Яндекс.Карты</span>
            </article>
          ))}
        </div>
        <Link href="/reviews" className="mt-5 inline-block text-sm font-semibold text-brand hover:underline">
          Смотреть все отзывы
        </Link>
      </section>

      <Faq />

      <div className="prose-site mt-14 max-w-3xl">
        <h2>Доставка цветов в Москве</h2>
        <p>
          «Букет в ответ» — сервис доставки цветов и подарков по Москве, МО и всей России. Мы работаем круглосуточно, собираем букеты из свежих цветов от лучших поставщиков и присылаем фото перед доставкой.
        </p>
        <p>Закажите цветы на сайте за пять минут: выберите букет, укажите адрес и время — курьер приедет точно в срок.</p>
      </div>
    </div>
  );
}
