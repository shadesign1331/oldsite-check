import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { OrderSummary } from "@/components/OrderSummary";

export const dynamic = "force-dynamic";
export const metadata = { title: "Заказ оформлен | Букет в ответ" };

export default async function OrderDone({ params }: { params: Promise<{ number: string }> }) {
  const { number } = await params;
  if (!/^\d{4,12}$/.test(number)) notFound();
  const [o] = await db.select().from(orders).where(eq(orders.number, number)).limit(1);
  if (!o) notFound();
  return (
    <div className="wrap max-w-[820px] py-10">
      <div className="mb-8 text-center">
        <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-brand-soft text-5xl">🌷</div>
        <h1 className="text-3xl font-bold">Спасибо! Заказ №{o.number} оформлен</h1>
        <p className="mt-3 text-muted">
          Мы отправим фото букета на {o.customerPhone} перед доставкой. Сохраните номер заказа — по нему можно{" "}
          <Link href={`/order-status?number=${o.number}`} className="text-brand underline">узнать статус</Link>.
        </p>
      </div>
      <OrderSummary o={o} />
      <div className="mt-8 text-center">
        <Link href="/" className="btn-brand inline-flex h-12 items-center px-8">
          Вернуться на главную
        </Link>
      </div>
    </div>
  );
}
