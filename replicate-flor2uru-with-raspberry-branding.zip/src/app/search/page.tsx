import { searchProducts } from "@/lib/catalog";
import { Breadcrumbs } from "@/components/Bits";
import { ProductGrid } from "@/components/ProductCard";

export const dynamic = "force-dynamic";
export const metadata = { title: "Поиск | Букет в ответ" };

export default async function SearchPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = "" } = await searchParams;
  const items = searchProducts(q);
  return (
    <div className="wrap">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "Поиск" }]} />
      <h1 className="mb-2 text-[34px] font-bold">Поиск: «{q}»</h1>
      <p className="mb-6 text-muted">Найдено: {items.length}</p>
      {items.length ? <ProductGrid items={items} /> : <p className="py-16 text-center text-muted">Ничего не найдено. Попробуйте «роза», «пион» или «коробка».</p>}
    </div>
  );
}
