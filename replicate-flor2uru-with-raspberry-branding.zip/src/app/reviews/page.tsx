import { MAP_REVIEWS, REVIEWS } from "@/lib/catalog";
import { Breadcrumbs, Stars, YandexBadge } from "@/components/Bits";

export const metadata = { title: "Отзывы клиентов | Букет в ответ" };

export default function Page() {
  const all = [...MAP_REVIEWS.map((r) => ({ name: r.name, text: r.text, date: r.date, img: "" })), ...REVIEWS.map((r) => ({ ...r, date: "" }))];
  return (
    <div className="wrap pb-6">
      <Breadcrumbs items={[{ label: "Главная", href: "/" }, { label: "Отзывы" }]} />
      <h1 className="mb-4 text-[34px] font-bold">Отзывы наших клиентов</h1>
      <div className="mb-8 flex items-center gap-4">
        <YandexBadge />
        <span className="text-5xl font-bold">4.7</span>
        <div>
          <Stars className="h-6 w-6" />
          <div className="text-xs text-muted">9132 отзыва • 4578 оценок</div>
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {all.map((r, i) => (
          <article key={i} className="overflow-hidden rounded-2xl bg-[#faf6f7]">
            {r.img && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={`/img/${r.img}.jpg`} alt={r.name} loading="lazy" className="h-64 w-full object-cover" />
            )}
            <div className="p-5">
              <div className="flex items-center justify-between">
                <b>{r.name}</b>
                <Stars className="h-3.5 w-3.5" />
              </div>
              {r.date && <div className="mb-2 text-xs text-muted">{r.date}</div>}
              <p className="mt-2 text-sm leading-relaxed text-ink/80">{r.text}</p>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
