import Link from "next/link";
import { InfoPage } from "@/components/InfoPage";

export const metadata = { title: "Акция 1+1=3 | Букет в ответ" };

export default function Page() {
  return (
    <InfoPage title="Акция 1+1=3">
      <div className="mb-8 flex flex-col gap-2 rounded-3xl bg-brand p-8 text-white md:flex-row md:items-center md:justify-between">
        <span className="text-6xl font-black">1+1=3</span>
        <span className="text-2xl leading-tight font-bold">Сделайте 2 заказа —<br />3-й букет за 1 ₽</span>
      </div>
      <p>Оформите два заказа на сайте — и третий букет получите всего за 1 рубль. Акция действует для зарегистрированных клиентов, бонусы по акции начисляются автоматически.</p>
      <p>Используйте промокод <b>BUKET10</b>, чтобы получить скидку 10% на первый заказ, или <b>WELCOME</b> — минус 300 ₽.</p>
      <Link href="/catalog/all-2" className="btn-brand mt-4 inline-flex h-12 items-center px-8">
        Выбрать букет
      </Link>
    </InfoPage>
  );
}
